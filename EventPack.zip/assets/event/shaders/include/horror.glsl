#ifndef EVENT_HORROR_GLSL
#define EVENT_HORROR_GLSL

#include <event:post_common.glsl>

// The heartbeat Tag's horror mode plays: a 32 tick cycle with a strong beat on
// tick 0 and a softer one on tick 6, counted from world time so it lines up
// with the server's sound (TagHorrorModifier). 0..1.
float horror_heartbeat() {
    float t = mod(fx_ticks(), 32.0);
    float first = exp(-t * 0.35);
    float second = t >= 6.0 ? 0.7 * exp(-(t - 6.0) * 0.35) : 0.0;
    return clamp(first + second, 0.0, 1.0);
}

// The world is drawn with reversed Z: depth 1 at the near plane, 0 at
// infinity (the sky). Distance in blocks from the camera.
#define HORROR_NEAR_PLANE 0.05

float horror_distance(float depth) {
    return depth <= 0.0 ? 100000.0 : HORROR_NEAR_PLANE / depth;
}

#endif
