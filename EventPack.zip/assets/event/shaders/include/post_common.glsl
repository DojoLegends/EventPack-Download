#ifndef EVENT_POST_COMMON_GLSL
#define EVENT_POST_COMMON_GLSL

#define FX_PI 3.14159265359

// Shared helpers for every event:* post effect. Time comes from world time, so
// all players on a server see the same frame of an animation together.

// GameTime is (gameTime % 24000 + partial) / 24000.
float fx_ticks() {
    return GameTime * 24000.0;
}

float fx_seconds() {
    return GameTime * 1200.0;
}

float fx_hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float fx_hash1(float x) {
    return fx_hash(vec2(x, x * 1.618));
}

// Smooth 1D value noise, 0..1.
float fx_noise(float x) {
    float i = floor(x);
    float f = fract(x);
    return mix(fx_hash1(i), fx_hash1(i + 1.0), f * f * (3.0 - 2.0 * f));
}

float fx_luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec3 fx_saturate(vec3 c, float amount) {
    return mix(vec3(fx_luma(c)), c, amount);
}

// 1 in the middle of the screen, falling to 0 at `outer` (in screen heights
// from the centre, so the falloff is round on any aspect ratio).
float fx_vignette(vec2 uv, vec2 size, float inner, float outer) {
    vec2 d = (uv - 0.5) * vec2(size.x / size.y, 1.0);
    return 1.0 - smoothstep(inner, outer, length(d));
}

// Film grain at 24 fps so it reads as grain rather than shimmer.
vec3 fx_grain(vec3 c, vec2 pixel, float amount) {
    float frame = floor(fx_seconds() * 24.0);
    float n = fx_hash(pixel + frame * vec2(17.0, 59.0)) - 0.5;
    return c + n * amount;
}

// Red and blue pulled apart along `offset` (in uv).
vec3 fx_split(sampler2D image, vec2 uv, vec2 offset) {
    return vec3(
        texture(image, uv + offset).r,
        texture(image, uv).g,
        texture(image, uv - offset).b
    );
}

// One-shot clock. A one-shot effect keeps a 1x1 persistent texel: RGB holds
// the GameTime it was added at as a 24-bit fraction, alpha 1 once written.
// The client throws persistent targets away when an effect is removed, so
// every add starts again from a cleared texel.
vec3 fx_clock_encode(float t) {
    float v = floor(clamp(t, 0.0, 1.0) * 16777215.0);
    float r = floor(v / 65536.0);
    float g = floor((v - r * 65536.0) / 256.0);
    float b = v - r * 65536.0 - g * 256.0;
    return vec3(r, g, b) / 255.0;
}

float fx_clock_decode(vec3 rgb) {
    vec3 bytes = floor(rgb * 255.0 + 0.5);
    return (bytes.r * 65536.0 + bytes.g * 256.0 + bytes.b) / 16777215.0;
}

// Seconds since the effect was added.
float fx_clock_elapsed(vec4 clock) {
    return fract(GameTime - fx_clock_decode(clock.rgb) + 1.0) * 1200.0;
}

#endif
