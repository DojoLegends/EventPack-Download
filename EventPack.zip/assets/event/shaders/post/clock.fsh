#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <event:post_common.glsl>

// The first pass of every one-shot effect: stamps the time the effect was
// added into its cleared persistent texel, then carries it forward unchanged.

uniform sampler2D ClockSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec4 clock = texture(ClockSampler, vec2(0.5));
    fragColor = clock.a < 0.5 ? vec4(fx_clock_encode(GameTime), 1.0) : clock;
}
