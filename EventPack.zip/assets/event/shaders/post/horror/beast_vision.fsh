#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <event:horror.glsl>

// The predator's eyes: the world drops to a dim red, the shape of everything
// is traced in bright embers from the depth buffer, and it all sinks into
// darkness with distance. Glowing outlines keep their colour, so whatever the
// game makes glow stands out.

#define BEAST_FOG_START 6.0
#define BEAST_FOG_END 42.0

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
    vec2 DepthSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

float logDistance(vec2 uv) {
    return log(horror_distance(texture(DepthSampler, uv).r));
}

void main() {
    vec2 texel = 1.0 / OutSize;
    vec3 scene = texture(InSampler, texCoord).rgb;
    float dist = horror_distance(texture(DepthSampler, texCoord).r);

    float gx = logDistance(texCoord + vec2(texel.x, 0.0)) - logDistance(texCoord - vec2(texel.x, 0.0));
    float gy = logDistance(texCoord + vec2(0.0, texel.y)) - logDistance(texCoord - vec2(0.0, texel.y));
    float edge = smoothstep(0.04, 0.25, length(vec2(gx, gy)));

    float fog = smoothstep(BEAST_FOG_START, BEAST_FOG_END, dist);
    float luma = fx_luma(scene);

    vec3 color = vec3(0.42, 0.03, 0.05) * (0.25 + luma * 1.5);
    color += vec3(1.0, 0.36, 0.16) * edge * 0.9;
    color *= 1.0 - 0.9 * fog;

    float saturation = max(scene.r, max(scene.g, scene.b)) - min(scene.r, min(scene.g, scene.b));
    color = mix(color, scene, smoothstep(0.65, 0.85, saturation) * step(0.35, luma));

    float scan = 0.94 + 0.06 * sin(texCoord.y * OutSize.y * 1.5 - fx_seconds() * 6.0);
    color *= scan * mix(0.35, 1.0, fx_vignette(texCoord, OutSize, 0.3, 0.9));

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
