#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <event:horror.glsl>

// A cheap security camera: a curved green monochrome tube with scanlines, a
// rolling bright band, signal noise, the odd tear across a few rows, and a
// blinking record light in the corner.

#define CCTV_CURVE 0.10
#define CCTV_LEVELS 20.0
#define CCTV_PHOSPHOR vec3(0.70, 1.00, 0.78)

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

vec2 curve(vec2 uv) {
    vec2 c = uv * 2.0 - 1.0;
    c *= 1.0 + CCTV_CURVE * vec2(dot(c, c)) * vec2(0.6, 1.0);
    return c * 0.5 + 0.5;
}

void main() {
    float t = fx_seconds();
    vec2 uv = curve(texCoord);
    if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    float row = floor(uv.y * OutSize.y / 3.0);
    float tearBand = floor(uv.y * 18.0);
    float tearing = step(0.93, fx_hash(vec2(tearBand, floor(t * 8.0))));
    uv.x += tearing * (fx_hash(vec2(row, floor(t * 30.0))) - 0.5) * 0.04;

    float luma = fx_luma(texture(InSampler, uv).rgb);
    luma = floor(luma * CCTV_LEVELS + 0.5) / CCTV_LEVELS;

    float scanline = mod(floor(uv.y * OutSize.y), 3.0) < 1.0 ? 0.72 : 1.0;
    float roll = smoothstep(0.08, 0.0, abs(fract(uv.y - t * 0.12) - 0.5) - 0.42);
    float noise = fx_hash(floor(uv * OutSize * 0.5) + floor(t * 30.0)) - 0.5;

    vec3 color = CCTV_PHOSPHOR * (luma * scanline + roll * 0.08 + noise * 0.12);
    color *= mix(0.25, 1.0, fx_vignette(texCoord, OutSize, 0.35, 0.95));

    vec2 recPixel = vec2(uv.x * OutSize.x, (1.0 - uv.y) * OutSize.y);
    float recSize = OutSize.y / 54.0;
    if (length(recPixel - vec2(3.0, 3.0) * recSize) < recSize && fract(t) < 0.5) {
        color = vec3(0.95, 0.10, 0.08);
    }

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
