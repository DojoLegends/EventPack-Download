#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <event:horror.glsl>

// The hunter's eyes in Tag's horror mode: the world drains to a dull rust,
// sinks into shadow with distance and narrows at the edges, while anything
// glowing - the runners - keeps its full colour and stands out.

#define STALKER_FOG_START 10.0
#define STALKER_FOG_END 48.0

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
    vec2 DepthSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec3 scene = texture(InSampler, texCoord).rgb;
    float dist = horror_distance(texture(DepthSampler, texCoord).r);
    float luma = fx_luma(scene);

    vec3 color = vec3(luma) * vec3(1.05, 0.78, 0.66);
    color = pow(max(color, 0.0), vec3(1.15));
    color *= 1.0 - 0.7 * smoothstep(STALKER_FOG_START, STALKER_FOG_END, dist);

    float saturation = max(scene.r, max(scene.g, scene.b)) - min(scene.r, min(scene.g, scene.b));
    color = mix(color, scene, smoothstep(0.6, 0.8, saturation) * step(0.3, luma));

    float breath = 0.5 + 0.5 * sin(fx_seconds() * 1.1);
    color *= mix(0.3, 1.0, fx_vignette(texCoord, OutSize, 0.28 + 0.03 * breath, 0.95));

    color = fx_grain(color, floor(texCoord * OutSize), 0.04);
    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
