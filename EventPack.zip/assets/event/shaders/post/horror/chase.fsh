#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <event:horror.glsl>

// Being hunted: the view smears towards the centre, the colour jitters apart,
// the edges pulse red fast and the light keeps catching.

#define CHASE_BLUR_TAPS 8

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    float t = fx_seconds();
    vec2 fromCentre = texCoord - 0.5;

    vec2 jitter = vec2(fx_noise(t * 14.0), fx_noise(t * 14.0 + 31.0)) - 0.5;
    vec2 split = fromCentre * 0.010 + jitter * 0.006;

    vec3 color = vec3(0.0);
    for (int i = 0; i < CHASE_BLUR_TAPS; i++) {
        float k = float(i) / float(CHASE_BLUR_TAPS);
        color += fx_split(InSampler, texCoord - fromCentre * k * 0.045, split);
    }
    color /= float(CHASE_BLUR_TAPS);

    float pulse = 0.5 + 0.5 * sin(t * 9.0);
    float rim = 1.0 - fx_vignette(texCoord, OutSize, 0.2, 0.8);
    color = mix(color, vec3(0.55, 0.02, 0.02), clamp(rim * (0.45 + 0.35 * pulse), 0.0, 1.0));

    float catchLight = fx_noise(t * 6.0) > 0.78 ? 0.65 : 1.0;
    color = mix(vec3(fx_luma(color)), color, 0.6) * catchLight;

    color = fx_grain(color, floor(texCoord * OutSize), 0.09);
    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
