#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <event:post_common.glsl>

// One shot. A kill lands: the edges warm for a moment and the colour lifts,
// then it settles back within half a second.

#define KILL_SECONDS 0.5

uniform sampler2D InSampler;
uniform sampler2D ClockSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
    vec2 ClockSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    float t = clamp(fx_clock_elapsed(texture(ClockSampler, vec2(0.5))) / KILL_SECONDS, 0.0, 1.0);
    float strength = (1.0 - t) * (1.0 - t);

    vec3 color = fx_saturate(texture(InSampler, texCoord).rgb, 1.0 + 0.2 * strength);
    float rim = 1.0 - fx_vignette(texCoord, OutSize, 0.35, 1.0);
    color = mix(color, vec3(1.0, 0.9, 0.7), rim * 0.22 * strength);
    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
