#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <event:post_common.glsl>

// Watching rather than playing, as if through a camera lens: the middle of
// the screen stays sharp and in full colour while the edges fall gently out
// of focus, fringe slightly and take on a faint cool cast.

#define SPECTATE_FOCUS_INNER 0.32
#define SPECTATE_FOCUS_OUTER 0.95
#define SPECTATE_FRINGE 0.006
#define SPECTATE_COOL vec3(0.92, 0.97, 1.06)

uniform sampler2D InSampler;
uniform sampler2D BlurSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
    vec2 BlurSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    float outOfFocus = 1.0 - fx_vignette(texCoord, OutSize, SPECTATE_FOCUS_INNER, SPECTATE_FOCUS_OUTER);

    vec2 fringe = (texCoord - 0.5) * SPECTATE_FRINGE * outOfFocus;
    vec3 sharp = fx_split(InSampler, texCoord, fringe);
    vec3 soft = fx_split(BlurSampler, texCoord, fringe);

    vec3 color = mix(sharp, soft, outOfFocus * 0.85);
    color *= mix(vec3(1.0), SPECTATE_COOL, outOfFocus);
    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
