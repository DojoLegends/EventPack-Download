// ---------------------------------------------------------------------------
// plate_effects.glsl
//
// Border effects drawn over a sized plate (event:sized_plates). The plate's
// effect glyph is a 2x64 texel cell whose alpha holds the data, written by
// buildSrc GenerateSizedPlatesTask in the event repo:
//   (0,0) (1,0) (0,1) (1,1)  PE_MARKER
//   (0,2) effect id          (1,2) height of the plated section
//   (0,3) glyph top -> section top, in GUI pixels
// The text colour carries the rest, packed by PlateEffect.kt:
//   R = red4 << 4 | green4
//   G = blue4 << 4 | speed3 << 1 | width bit 8
//   B = width bits 0..7
// The vertex shader stretches the glyph over the plate and the fragment
// shader draws a 1px ring on the plate's edge pixels, filling the pixel inside
// each of the notched corners the plate itself leaves out.
// ---------------------------------------------------------------------------

#define PE_MARKER 23
#define PE_CELL_PX vec2(2.0, 64.0)

#define PE_EFFECT_FLASH 1
#define PE_EFFECT_ENCIRCLE 2

// lbStyle values, kept clear of the loading bar styles.
#define PE_STYLE_BASE 15
#define PE_STYLE_FLASH (PE_STYLE_BASE + PE_EFFECT_FLASH)
#define PE_STYLE_ENCIRCLE (PE_STYLE_BASE + PE_EFFECT_ENCIRCLE)

// Seconds per flash or per lap, indexed by the speed bits. Must match
// PlateEffectSpeed.kt.
const float PE_PERIODS[8] = float[8](4.0, 3.0, 2.0, 1.5, 1.0, 0.75, 0.5, 0.25);

#define PE_ENCIRCLE_FRACTION 0.25
#define PE_ENCIRCLE_MIN 4.0
#define PE_ENCIRCLE_MAX 32.0

// Clockwise distance along the ring, starting right of the top-left notch, or
// -1 when pixel `p` is not on the ring.
float pe_ring_position(vec2 p, vec2 size) {
    float right = size.x - 1.0;
    float bottom = size.y - 1.0;
    float across = size.x - 2.0;
    float down = size.y - 2.0;
    bool onTop = p.y == 0.0;
    bool onBottom = p.y == bottom;
    bool onLeft = p.x == 0.0;
    bool onRight = p.x == right;
    if ((onTop || onBottom) && (onLeft || onRight)) return -1.0;
    if (onTop) return p.x - 1.0;
    if (onRight) return across + p.y - 1.0;
    if (onBottom) return across + down + (right - 1.0 - p.x);
    if (onLeft) return 2.0 * across + down + (bottom - 1.0 - p.y);
    return -1.0;
}

float pe_ring_length(vec2 size) {
    return 2.0 * (size.x - 2.0) + 2.0 * (size.y - 2.0);
}

vec4 pe_flash(float period, vec3 colour, float time) {
    return fract(time / period) < 0.5 ? vec4(colour, 1.0) : vec4(0.0);
}

vec4 pe_encircle(float s, vec2 size, float period, vec3 colour, float time) {
    float lap = pe_ring_length(size);
    float head = floor(fract(time / period) * lap);
    float behind = mod(head - s + lap, lap);
    float segment = clamp(floor(lap * PE_ENCIRCLE_FRACTION), PE_ENCIRCLE_MIN, PE_ENCIRCLE_MAX);
    return behind < segment ? vec4(colour, 1.0) : vec4(0.0);
}

vec4 pe_effect(int style, float s, vec2 size, float period, vec3 colour, float time) {
    if (style == PE_STYLE_FLASH) return pe_flash(period, colour, time);
    if (style == PE_STYLE_ENCIRCLE) return pe_encircle(s, size, period, colour, time);
    return vec4(0.0);
}

// The pixel diagonally inside each notch, which fills the corner so the ring
// turns it as a solid L instead of stepping diagonally across it.
bool pe_inner_corner(vec2 p, vec2 size) {
    return (p.x == 1.0 || p.x == size.x - 2.0) && (p.y == 1.0 || p.y == size.y - 2.0);
}

// `local` runs 0..size across the plate from its top left, in GUI pixels.
vec4 pe_render(int style, vec2 local, vec2 size, float period, vec3 colour, float time) {
    vec2 p = floor(local);
    float s = pe_ring_position(p, size);
    if (s >= 0.0) return pe_effect(style, s, size, period, colour, time);
    if (!pe_inner_corner(p, size)) return vec4(0.0);

    // Lit whenever either ring pixel beside it is.
    vec2 edge = vec2(p.x == 1.0 ? 0.0 : size.x - 1.0, p.y == 1.0 ? 0.0 : size.y - 1.0);
    vec4 alongEdge = pe_effect(style, pe_ring_position(vec2(p.x, edge.y), size), size, period, colour, time);
    if (alongEdge.a > 0.0) return alongEdge;
    return pe_effect(style, pe_ring_position(vec2(edge.x, p.y), size), size, period, colour, time);
}
