// ---------------------------------------------------------------------------
// loading_bars.glsl
//
// Screen-space loading indicators for rendertype_text.
// All layout is done in GUI pixels (origin top-left, y down) so everything
// stays the same physical size at every GUI scale / resolution.
//
// See docs/screen_shaders.md for the text-component encoding.
// ---------------------------------------------------------------------------

#define LB_PI  3.14159265359
#define LB_TAU 6.28318530718

#define LB_MAX_STYLE 7

// Source size of textures/font/loading_screen.png. Must match LB_GLYPH_PX in
// core/rendertype_text.vsh and SIZE in tools/bake_logo.py.
#define LB_GLYPH_PX 80.0

// The trigger marker lives in the glyph's top-left 2x2 texels; mask it out so
// it never shows up inside the logo.
#define LB_MARKER_PX 2.0

#define LB_TRACK      vec4(0.04, 0.04, 0.06, 0.85)
// Ring track is lighter than the bar track so it still reads against the dark
// loading-screen backdrop.
#define LB_RING_TRACK vec4(0.34, 0.34, 0.42, 0.60)
#define LB_PANEL      vec4(0.05, 0.05, 0.07, 0.80)
#define LB_PANEL_EDGE vec4(0.19, 0.19, 0.24, 0.90)

// Integer-aligned box test. `p` is expected to be a GUI pixel centre
// (floor(coord) + 0.5), so `x`,`y`,`w`,`h` behave like exact pixel rects.
bool lb_box(vec2 p, float x, float y, float w, float h) {
    return p.x >= x && p.x < x + w && p.y >= y && p.y < y + h;
}

// 0 -> red, 1/3 -> green, 2/3 -> blue.
vec3 lb_hue(float t) {
    t = fract(t);
    float r = abs(t * 6.0 - 3.0) - 1.0;
    float g = 2.0 - abs(t * 6.0 - 2.0);
    float b = 2.0 - abs(t * 6.0 - 4.0);
    return clamp(vec3(r, g, b), 0.0, 1.0);
}

// Blue channel of the text colour -> accent colour.
//   0   = white
//   255 = animated rainbow
//   else hue = b / 255
vec3 lb_accent(float b, float time) {
    if (b < 0.5)   return vec3(1.0);
    if (b > 254.5) return lb_hue(time * 0.25);
    return lb_hue(b / 255.0);
}

// Source-over composite of `src` on top of `dst`.
vec4 lb_over(vec4 src, vec4 dst) {
    float a = src.a + dst.a * (1.0 - src.a);
    if (a <= 0.0) return vec4(0.0);
    return vec4((src.rgb * src.a + dst.rgb * dst.a * (1.0 - src.a)) / a, a);
}

// Dark backing panel with 1px notched corners, so bars read against any world.
vec4 lb_panel(vec2 p, float x, float y, float w, float h) {
    if (!lb_box(p, x, y, w, h)) return vec4(0.0);
    vec2 d = min(p - vec2(x, y), vec2(x + w, y + h) - p);
    if (d.x < 1.0 && d.y < 1.0) return vec4(0.0);       // clipped corner
    if (d.x < 1.0 || d.y < 1.0) return LB_PANEL_EDGE;   // outline
    return LB_PANEL;
}

// Angle of `p` around `c`, 0 at 12 o'clock, growing clockwise, wrapped to 0..1.
// Returns false outside the ring band.
bool lb_ring(vec2 p, vec2 c, float radius, float thick, out float angle) {
    vec2 d = p - c;
    float r = length(d);
    angle = fract(atan(d.x, -d.y) / LB_TAU);
    return r >= radius - thick && r <= radius;
}

// ---------------------------------------------------------------------------
// Spinner - always spinning. A comet chasing its own tail; progress is not
// involved, this is a "working on it" indicator.
// ---------------------------------------------------------------------------
vec4 lb_spin(vec2 p, vec2 c, float radius, float thick, vec3 col, float time) {
    float a;
    if (!lb_ring(p, c, radius, thick, a)) return vec4(0.0);

    float head = fract(time * 0.85);
    float tail = fract(head - a);
    float k = 1.0 - smoothstep(0.0, 0.6, tail);
    return lb_over(vec4(col, k), LB_RING_TRACK);
}

// ---------------------------------------------------------------------------
// Arc - determinate ring, sweeping clockwise from 12 o'clock.
// ---------------------------------------------------------------------------
vec4 lb_arc(vec2 p, vec2 c, float radius, float thick, float progress, vec3 col) {
    float a;
    if (!lb_ring(p, c, radius, thick, a)) return vec4(0.0);

    if (a <= progress) {
        float lead = smoothstep(progress - 0.3, progress, a);
        return vec4(clamp(col * (0.7 + 0.5 * lead), 0.0, 1.0), 1.0);
    }
    return LB_RING_TRACK;
}

// ---------------------------------------------------------------------------
// Logo
//   Sampled 1:1 out of the trigger glyph's own slot in the font atlas.
// ---------------------------------------------------------------------------
vec4 lb_logo(vec2 p, float x, float y, sampler2D atlas, vec2 uvOrigin, vec2 uvSize) {
    vec2 lp = p - vec2(x, y);
    if (lp.x < 0.0 || lp.y < 0.0 || lp.x >= LB_GLYPH_PX || lp.y >= LB_GLYPH_PX) return vec4(0.0);

    vec2 t = floor(lp);
    if (t.x < LB_MARKER_PX && t.y < LB_MARKER_PX) return vec4(0.0);

    return texture(atlas, uvOrigin + (t + 0.5) / LB_GLYPH_PX * uvSize);
}

// ---------------------------------------------------------------------------
// 1 - Classic bar
//   182x9 framed bar on a panel, three quarters down the screen.
// ---------------------------------------------------------------------------
vec4 lb_style_classic(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float W = 182.0;
    const float H = 9.0;
    float x = floor(gui.x * 0.5 - W * 0.5);
    float y = floor(gui.y * 0.72);

    vec4 result = lb_panel(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
    if (!lb_box(p, x, y, W, H)) return result;

    // 1px frame
    if (!lb_box(p, x + 1.0, y + 1.0, W - 2.0, H - 2.0)) {
        return lb_over(vec4(col * 0.55, 1.0), result);
    }

    float innerX = x + 2.0;
    float innerW = W - 4.0;
    float fill = floor(innerW * progress);

    if (p.x < innerX + fill) {
        // Diagonal sheen sliding along the fill.
        float band = fract((p.x - p.y) * 0.05 - time * 0.6);
        float sheen = 0.85 + 0.15 * smoothstep(0.75, 1.0, band);
        float shade = p.y < y + 3.0 ? 1.15 : (p.y > y + H - 4.0 ? 0.75 : 1.0);
        return lb_over(vec4(clamp(col * sheen * shade, 0.0, 1.0), 1.0), result);
    }

    return lb_over(LB_TRACK, result);
}

// ---------------------------------------------------------------------------
// 2 - Segmented bar
//   20 cells of 8x8 with a 1px gap. The cell being filled pulses.
// ---------------------------------------------------------------------------
vec4 lb_style_segments(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float CELLS = 20.0;
    const float CELL = 8.0;
    const float GAP = 1.0;
    const float H = 8.0;
    float W = CELLS * CELL + (CELLS - 1.0) * GAP;

    float x = floor(gui.x * 0.5 - W * 0.5);
    float y = floor(gui.y * 0.72);

    vec4 result = lb_panel(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
    if (!lb_box(p, x, y, W, H)) return result;

    float local = p.x - x;
    float index = floor(local / (CELL + GAP));
    if (local - index * (CELL + GAP) >= CELL) return result; // gap

    float filled = progress * CELLS;
    if (index < floor(filled)) {
        return lb_over(vec4(col, 1.0), result);
    }
    if (index < filled) {
        float pulse = 0.45 + 0.35 * sin(time * 6.0);
        return lb_over(vec4(col * pulse, 1.0), result);
    }
    return lb_over(LB_TRACK, result);
}

// ---------------------------------------------------------------------------
// 3 - Top progress bar
//   Full width, 3px, pinned to the top of the screen with a leading glow.
// ---------------------------------------------------------------------------
vec4 lb_style_top(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float H = 3.0;
    if (p.y >= H + 1.0) return vec4(0.0);
    if (p.y >= H) return vec4(0.0, 0.0, 0.0, 0.45);   // 1px drop shadow

    float head = floor(gui.x * progress);
    if (p.x < head) {
        float edge = smoothstep(head - 24.0, head, p.x);
        return vec4(clamp(col * (0.8 + 0.6 * edge), 0.0, 1.0), 1.0);
    }
    float glow = clamp(1.0 - (p.x - head) / 10.0, 0.0, 1.0);
    return lb_over(vec4(col, glow * 0.45), LB_TRACK);
}

// ---------------------------------------------------------------------------
// 4 - Ring
//   26px radius ring in the centre on a dark disc.
// ---------------------------------------------------------------------------
vec4 lb_style_ring(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float RADIUS = 26.0;
    const float THICK = 5.0;

    vec2 c = vec2(floor(gui.x * 0.5), floor(gui.y * 0.5));
    float r = length(p - c);

    vec4 result = vec4(0.0);
    if (r <= RADIUS + 4.0) result = LB_PANEL;
    if (r > RADIUS + 3.0 && r <= RADIUS + 4.0) result = LB_PANEL_EDGE;

    return lb_over(lb_arc(p, c, RADIUS, THICK, progress, col), result);
}

// ---------------------------------------------------------------------------
// 5 - Indeterminate marquee
//   Ignores progress. A block slides back and forth inside a framed track.
// ---------------------------------------------------------------------------
vec4 lb_style_marquee(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float W = 182.0;
    const float H = 9.0;
    const float BLOCK = 46.0;

    float x = floor(gui.x * 0.5 - W * 0.5);
    float y = floor(gui.y * 0.72);

    vec4 result = lb_panel(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
    if (!lb_box(p, x, y, W, H)) return result;
    if (!lb_box(p, x + 1.0, y + 1.0, W - 2.0, H - 2.0)) {
        return lb_over(vec4(col * 0.55, 1.0), result);
    }

    float innerX = x + 2.0;
    float travel = (W - 4.0) - BLOCK;

    // Ping-pong with an ease at both ends.
    float eased = 0.5 - 0.5 * cos(fract(time * 0.4) * LB_TAU);
    float local = p.x - (innerX + floor(travel * eased));

    if (local >= 0.0 && local < BLOCK) {
        float taper = clamp(min(local, BLOCK - 1.0 - local) / 8.0, 0.0, 1.0);
        return lb_over(vec4(clamp(col * (0.5 + 0.6 * taper), 0.0, 1.0), 1.0), result);
    }
    return lb_over(LB_TRACK, result);
}

// ---------------------------------------------------------------------------
// 6 - Loading screen
//   Opaque backdrop, logo above centre, small spinner below it. The spinner
//   always spins; progress is ignored by this style.
// ---------------------------------------------------------------------------
vec4 lb_style_loading_screen(vec2 p, vec2 gui, float progress, vec3 col, float time,
                             sampler2D atlas, vec2 uvOrigin, vec2 uvSize) {
    float cx = floor(gui.x * 0.5);
    float cy = floor(gui.y * 0.5);

    // Backdrop with a gentle vignette.
    vec2 n = (p / gui - 0.5) * vec2(1.6, 1.0);
    float vignette = 1.0 - 0.55 * clamp(length(n), 0.0, 1.0);
    vec4 result = vec4(vec3(0.030, 0.030, 0.042) * (0.55 + 0.45 * vignette), 0.96);

    // Faint accent bloom behind the logo.
    float bloom = 1.0 - clamp(length((p - vec2(cx, cy - 18.0)) / vec2(95.0, 75.0)), 0.0, 1.0);
    result = lb_over(vec4(col, bloom * bloom * 0.12), result);

    result = lb_over(lb_logo(p, cx - LB_GLYPH_PX * 0.5, cy - 58.0, atlas, uvOrigin, uvSize), result);
    result = lb_over(lb_spin(p, vec2(cx, cy + 46.0), 13.0, 3.0, col, time), result);

    return result;
}

// ---------------------------------------------------------------------------
// 7 - Bare spinner
//   Small centred spinner, nothing else. Always spinning.
// ---------------------------------------------------------------------------
vec4 lb_style_spinner(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    vec2 c = vec2(floor(gui.x * 0.5), floor(gui.y * 0.5));
    return lb_spin(p, c, 13.0, 3.0, col, time);
}

// ---------------------------------------------------------------------------
// Dispatcher
// ---------------------------------------------------------------------------
vec4 lb_render(int style, vec2 guiCoord, vec2 gui, float progress, float hueByte, float time,
               sampler2D atlas, vec2 uvOrigin, vec2 uvSize) {
    vec2 p = floor(guiCoord) + 0.5;
    vec3 col = lb_accent(hueByte, time);
    progress = clamp(progress, 0.0, 1.0);

    if (style == 1) return lb_style_classic(p, gui, progress, col, time);
    if (style == 2) return lb_style_segments(p, gui, progress, col, time);
    if (style == 3) return lb_style_top(p, gui, progress, col, time);
    if (style == 4) return lb_style_ring(p, gui, progress, col, time);
    if (style == 5) return lb_style_marquee(p, gui, progress, col, time);
    if (style == 6) return lb_style_loading_screen(p, gui, progress, col, time, atlas, uvOrigin, uvSize);
    if (style == 7) return lb_style_spinner(p, gui, progress, col, time);
    return vec4(0.0);
}
