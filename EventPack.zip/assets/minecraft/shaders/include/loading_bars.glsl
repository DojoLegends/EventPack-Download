// ---------------------------------------------------------------------------
// loading_bars.glsl
//
// Screen-space loading indicators for rendertype_text.
// All layout is done in GUI pixels (origin top-left, y down) so everything
// stays the same physical size at every GUI scale / resolution.
//
// See docs/screen_shaders.md for the text-component encoding.
// ---------------------------------------------------------------------------

#define LB_PI  3.14159265359
#define LB_TAU 6.28318530718

#define LB_MAX_STYLE 7
#define LB_STYLE_LOADING_SCREEN 6

// Source size of textures/font/loading_screen.png. Must match LB_GLYPH_PX in
// core/rendertype_text.vsh and SIZE in tools/bake_logo.py.
#define LB_GLYPH_PX 252.0

// The trigger marker lives in the glyph's top-left 2x2 texels; mask it out so
// it never shows up inside the logo.
#define LB_MARKER_PX 2.0

#define LB_TRACK      vec4(0.04, 0.04, 0.06, 0.85)
// Ring track is lighter than the bar track so it still reads against the dark
// loading-screen backdrop.
#define LB_RING_TRACK vec4(0.34, 0.34, 0.42, 0.60)
#define LB_PANEL      vec4(0.05, 0.05, 0.07, 0.80)
#define LB_PANEL_EDGE vec4(0.19, 0.19, 0.24, 0.90)

// Integer-aligned box test. `p` is expected to be a GUI pixel centre
// (floor(coord) + 0.5), so `x`,`y`,`w`,`h` behave like exact pixel rects.
bool lb_box(vec2 p, float x, float y, float w, float h) {
    return p.x >= x && p.x < x + w && p.y >= y && p.y < y + h;
}

// 0 -> red, 1/3 -> green, 2/3 -> blue.
vec3 lb_hue(float t) {
    t = fract(t);
    float r = abs(t * 6.0 - 3.0) - 1.0;
    float g = 2.0 - abs(t * 6.0 - 2.0);
    float b = 2.0 - abs(t * 6.0 - 4.0);
    return clamp(vec3(r, g, b), 0.0, 1.0);
}

// Blue channel of the text colour -> accent colour.
//   0   = white
//   255 = animated rainbow
//   else hue = b / 255
vec3 lb_accent(float b, float time) {
    if (b < 0.5)   return vec3(1.0);
    if (b > 254.5) return lb_hue(time * 0.25);
    return lb_hue(b / 255.0);
}

// Source-over composite of `src` on top of `dst`.
vec4 lb_over(vec4 src, vec4 dst) {
    float a = src.a + dst.a * (1.0 - src.a);
    if (a <= 0.0) return vec4(0.0);
    return vec4((src.rgb * src.a + dst.rgb * dst.a * (1.0 - src.a)) / a, a);
}

// Dark backing panel with 1px notched corners, so bars read against any world.
vec4 lb_panel(vec2 p, float x, float y, float w, float h) {
    if (!lb_box(p, x, y, w, h)) return vec4(0.0);
    vec2 d = min(p - vec2(x, y), vec2(x + w, y + h) - p);
    if (d.x < 1.0 && d.y < 1.0) return vec4(0.0);       // clipped corner
    if (d.x < 1.0 || d.y < 1.0) return LB_PANEL_EDGE;   // outline
    return LB_PANEL;
}

// Angle of `p` around `c`, 0 at 12 o'clock, growing clockwise, wrapped to 0..1.
// Returns false outside the ring band.
bool lb_ring(vec2 p, vec2 c, float radius, float thick, out float angle) {
    vec2 d = p - c;
    float r = length(d);
    angle = fract(atan(d.x, -d.y) / LB_TAU);
    return r >= radius - thick && r <= radius;
}

// ---------------------------------------------------------------------------
// Spinner - always spinning. A comet chasing its own tail; progress is not
// involved, this is a "working on it" indicator.
// ---------------------------------------------------------------------------
vec4 lb_spin(vec2 p, vec2 c, float radius, float thick, vec3 col, float time) {
    float a;
    if (!lb_ring(p, c, radius, thick, a)) return vec4(0.0);

    float head = fract(time * 0.85);
    float tail = fract(head - a);
    float k = 1.0 - smoothstep(0.0, 0.6, tail);
    return lb_over(vec4(col, k), LB_RING_TRACK);
}

// ---------------------------------------------------------------------------
// Arc - determinate ring, sweeping clockwise from 12 o'clock.
// ---------------------------------------------------------------------------
vec4 lb_arc(vec2 p, vec2 c, float radius, float thick, float progress, vec3 col) {
    float a;
    if (!lb_ring(p, c, radius, thick, a)) return vec4(0.0);

    if (a <= progress) {
        float lead = smoothstep(progress - 0.3, progress, a);
        return vec4(clamp(col * (0.7 + 0.5 * lead), 0.0, 1.0), 1.0);
    }
    return LB_RING_TRACK;
}

// ---------------------------------------------------------------------------
// 1 - Classic bar
//   182x9 framed bar on a panel, three quarters down the screen.
// ---------------------------------------------------------------------------
vec4 lb_style_classic(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float W = 182.0;
    const float H = 9.0;
    float x = floor(gui.x * 0.5 - W * 0.5);
    float y = floor(gui.y * 0.72);

    vec4 result = lb_panel(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
    if (!lb_box(p, x, y, W, H)) return result;

    // 1px frame
    if (!lb_box(p, x + 1.0, y + 1.0, W - 2.0, H - 2.0)) {
        return lb_over(vec4(col * 0.55, 1.0), result);
    }

    float innerX = x + 2.0;
    float innerW = W - 4.0;
    float fill = floor(innerW * progress);

    if (p.x < innerX + fill) {
        // Diagonal sheen sliding along the fill.
        float band = fract((p.x - p.y) * 0.05 - time * 0.6);
        float sheen = 0.85 + 0.15 * smoothstep(0.75, 1.0, band);
        float shade = p.y < y + 3.0 ? 1.15 : (p.y > y + H - 4.0 ? 0.75 : 1.0);
        return lb_over(vec4(clamp(col * sheen * shade, 0.0, 1.0), 1.0), result);
    }

    return lb_over(LB_TRACK, result);
}

// ---------------------------------------------------------------------------
// 2 - Segmented bar
//   20 cells of 8x8 with a 1px gap. The cell being filled pulses.
// ---------------------------------------------------------------------------
vec4 lb_style_segments(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float CELLS = 20.0;
    const float CELL = 8.0;
    const float GAP = 1.0;
    const float H = 8.0;
    float W = CELLS * CELL + (CELLS - 1.0) * GAP;

    float x = floor(gui.x * 0.5 - W * 0.5);
    float y = floor(gui.y * 0.72);

    vec4 result = lb_panel(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
    if (!lb_box(p, x, y, W, H)) return result;

    float local = p.x - x;
    float index = floor(local / (CELL + GAP));
    if (local - index * (CELL + GAP) >= CELL) return result; // gap

    float filled = progress * CELLS;
    if (index < floor(filled)) {
        return lb_over(vec4(col, 1.0), result);
    }
    if (index < filled) {
        float pulse = 0.45 + 0.35 * sin(time * 6.0);
        return lb_over(vec4(col * pulse, 1.0), result);
    }
    return lb_over(LB_TRACK, result);
}

// ---------------------------------------------------------------------------
// 3 - Top progress bar
//   Full width, 3px, pinned to the top of the screen with a leading glow.
// ---------------------------------------------------------------------------
vec4 lb_style_top(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float H = 3.0;
    if (p.y >= H + 1.0) return vec4(0.0);
    if (p.y >= H) return vec4(0.0, 0.0, 0.0, 0.45);   // 1px drop shadow

    float head = floor(gui.x * progress);
    if (p.x < head) {
        float edge = smoothstep(head - 24.0, head, p.x);
        return vec4(clamp(col * (0.8 + 0.6 * edge), 0.0, 1.0), 1.0);
    }
    float glow = clamp(1.0 - (p.x - head) / 10.0, 0.0, 1.0);
    return lb_over(vec4(col, glow * 0.45), LB_TRACK);
}

// ---------------------------------------------------------------------------
// 4 - Ring
//   26px radius ring in the centre on a dark disc.
// ---------------------------------------------------------------------------
vec4 lb_style_ring(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float RADIUS = 26.0;
    const float THICK = 5.0;

    vec2 c = vec2(floor(gui.x * 0.5), floor(gui.y * 0.5));
    float r = length(p - c);

    vec4 result = vec4(0.0);
    if (r <= RADIUS + 4.0) result = LB_PANEL;
    if (r > RADIUS + 3.0 && r <= RADIUS + 4.0) result = LB_PANEL_EDGE;

    return lb_over(lb_arc(p, c, RADIUS, THICK, progress, col), result);
}

// ---------------------------------------------------------------------------
// 5 - Indeterminate marquee
//   Ignores progress. A block slides back and forth inside a framed track.
// ---------------------------------------------------------------------------
vec4 lb_style_marquee(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    const float W = 182.0;
    const float H = 9.0;
    const float BLOCK = 46.0;

    float x = floor(gui.x * 0.5 - W * 0.5);
    float y = floor(gui.y * 0.72);

    vec4 result = lb_panel(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
    if (!lb_box(p, x, y, W, H)) return result;
    if (!lb_box(p, x + 1.0, y + 1.0, W - 2.0, H - 2.0)) {
        return lb_over(vec4(col * 0.55, 1.0), result);
    }

    float innerX = x + 2.0;
    float travel = (W - 4.0) - BLOCK;

    // Ping-pong with an ease at both ends.
    float eased = 0.5 - 0.5 * cos(fract(time * 0.4) * LB_TAU);
    float local = p.x - (innerX + floor(travel * eased));

    if (local >= 0.0 && local < BLOCK) {
        float taper = clamp(min(local, BLOCK - 1.0 - local) / 8.0, 0.0, 1.0);
        return lb_over(vec4(clamp(col * (0.5 + 0.6 * taper), 0.0, 1.0), 1.0), result);
    }
    return lb_over(LB_TRACK, result);
}

// ---------------------------------------------------------------------------
// 6 - Loading screen
//   The Dojo loading screen, in the website's colours: a flat dark field
//   with an asanoha (hemp leaf) lattice drifting slowly across it, the torii
//   sits above centre and a vermilion spinner just below. Sized from the
//   window height so it is the same at any resolution or GUI scale.
//
//   `coverage` is the text's alpha, so a title's fade in and out fades it.
//   `live` is false on vanilla screens with no world loaded: GameTime stands
//   still there and nothing else can tell the time, so the frame is drawn
//   still, spinner included.
// ---------------------------------------------------------------------------
#define LB_LS_FIELD       vec3(0.064, 0.053, 0.053)
#define LB_LS_LATTICE     vec3(0.140, 0.122, 0.122)
#define LB_LS_VERMILION   vec3(1.000, 0.246, 0.223)
#define LB_LS_TRACK       vec3(0.187, 0.163, 0.162)

// The icon's rectangle inside the glyph, in texels (bake_logo.py prints both).
#define LB_LS_LOGO_TEXELS vec2(239.0, 234.0)
#define LB_LS_LOGO_CENTRE vec2(125.5, 121.0)

// Layout, as fractions of the window height.
#define LB_LS_LOGO_HEIGHT  0.11
#define LB_LS_LOGO_GAP     0.03
#define LB_LS_SPINNER_Y    0.06
#define LB_LS_SPINNER_R    0.022
#define LB_LS_SPINNER_W    0.0055

// Asanoha triangles, in window heights per side, and how far the lattice
// drifts each second, in triangle sides.
#define LB_LS_LATTICE_SIZE 0.11
#define LB_LS_LATTICE_DRIFT vec2(0.14, 0.07)
// Half the lattice line width in pixels. Lines are drawn with a one pixel
// linear edge, so a line covers the same total brightness wherever it falls
// between pixels and the drift reads as a steady slide, not a shimmer.
#define LB_LS_LATTICE_HALF_WIDTH 0.6

float lb_ls_ease(float x) {
    x = clamp(x, 0.0, 1.0);
    return x * x * (3.0 - 2.0 * x);
}

float lb_ls_segment(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a;
    vec2 ba = b - a;
    return length(pa - ba * clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0));
}

// Asanoha: a lattice of equilateral triangles, each also split by lines from
// its centre to its corners. Returns the distance to the nearest line, in
// lattice units (one triangle side).
float lb_ls_asanoha(vec2 p) {
    const float H = 0.86602540378;
    float v = p.y / H;
    float u = p.x - 0.5 * v;

    float d = min(abs(fract(u + 0.5) - 0.5), abs(fract(v + 0.5) - 0.5));
    d = min(d, abs(fract(u + v + 0.5) - 0.5)) * H;

    vec2 cell = floor(vec2(u, v));
    vec2 f = vec2(u, v) - cell;
    vec2 c0, c1, c2;
    if (f.x + f.y < 1.0) {
        c0 = cell; c1 = cell + vec2(1.0, 0.0); c2 = cell + vec2(0.0, 1.0);
    } else {
        c0 = cell + vec2(1.0, 1.0); c1 = cell + vec2(1.0, 0.0); c2 = cell + vec2(0.0, 1.0);
    }
    vec2 v0 = vec2(c0.x + 0.5 * c0.y, c0.y * H);
    vec2 v1 = vec2(c1.x + 0.5 * c1.y, c1.y * H);
    vec2 v2 = vec2(c2.x + 0.5 * c2.y, c2.y * H);
    vec2 centre = (v0 + v1 + v2) / 3.0;
    d = min(d, lb_ls_segment(p, centre, v0));
    d = min(d, lb_ls_segment(p, centre, v1));
    d = min(d, lb_ls_segment(p, centre, v2));
    return d;
}

vec3 lb_ls_background(vec2 screen, vec2 size, float time) {
    vec3 color = LB_LS_FIELD;

    float side = size.y * LB_LS_LATTICE_SIZE;
    vec2 p = screen / side + time * LB_LS_LATTICE_DRIFT;
    float line = lb_ls_asanoha(p) * side;
    return mix(color, LB_LS_LATTICE, clamp(LB_LS_LATTICE_HALF_WIDTH + 0.5 - line, 0.0, 1.0));
}

// Bilinear sample of the glyph's icon at texel position `t` (0..LB_GLYPH_PX),
// kept inside the glyph and premultiplied so edges blend cleanly.
vec4 lb_ls_logo_texel(sampler2D atlas, vec2 uvOrigin, vec2 uvSize, vec2 t) {
    t = clamp(t, vec2(0.0), vec2(LB_GLYPH_PX - 1.0));
    if (t.x < LB_MARKER_PX && t.y < LB_MARKER_PX) return vec4(0.0);
    vec4 c = texture(atlas, uvOrigin + (t + 0.5) / LB_GLYPH_PX * uvSize);
    return vec4(c.rgb * c.a, c.a);
}

vec4 lb_ls_logo(vec2 screen, vec2 centre, float height, sampler2D atlas, vec2 uvOrigin, vec2 uvSize) {
    float texelsPerPixel = LB_LS_LOGO_TEXELS.y / height;
    vec2 t = (screen - centre) * texelsPerPixel + LB_LS_LOGO_CENTRE - 0.5;
    vec2 extent = LB_LS_LOGO_TEXELS * 0.5 + 1.0;
    if (any(greaterThan(abs(t + 0.5 - LB_LS_LOGO_CENTRE), extent))) return vec4(0.0);

    // Shrinking the icon several times over: average a few bilinear taps so
    // its outlines stay smooth instead of shimmering.
    vec2 spread = vec2(texelsPerPixel * 0.25);
    vec4 sum = vec4(0.0);
    for (int i = 0; i < 4; i++) {
        vec2 offset = vec2(i == 1 || i == 3 ? 1.0 : -1.0, i >= 2 ? 1.0 : -1.0) * spread;
        vec2 q = t + offset;
        vec2 base = floor(q);
        vec2 f = q - base;
        vec4 a = lb_ls_logo_texel(atlas, uvOrigin, uvSize, base);
        vec4 b = lb_ls_logo_texel(atlas, uvOrigin, uvSize, base + vec2(1.0, 0.0));
        vec4 c = lb_ls_logo_texel(atlas, uvOrigin, uvSize, base + vec2(0.0, 1.0));
        vec4 d = lb_ls_logo_texel(atlas, uvOrigin, uvSize, base + vec2(1.0, 1.0));
        sum += mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
    }
    return sum * 0.25;
}

// A vermilion arc with square ends running round a dark track. Each cycle the
// head runs ahead and then the tail catches it up, starting where the last
// cycle ended, so it never jumps. With `live` false it is drawn still.
vec4 lb_ls_spinner(vec2 screen, vec2 centre, float radius, float width, float time, bool live) {
    vec2 d = screen - centre;
    float dist = length(d);
    float edge = width * 0.5;
    float band = 1.0 - smoothstep(edge - 0.75, edge + 0.75, abs(dist - radius));
    if (band <= 0.0) return vec4(0.0);

    const float SWEEP = 0.72;
    const float MIN_ARC = 0.05;
    float start = 0.08;
    float arcLength = 0.3;
    if (live) {
        float cycle = time * 0.65;
        float phase = fract(cycle);
        float head = lb_ls_ease(phase * 2.0) * SWEEP;
        float tail = lb_ls_ease(phase * 2.0 - 1.0) * SWEEP;
        start = fract(time * 0.3 + floor(cycle) * SWEEP + tail);
        arcLength = head - tail + MIN_ARC;
    }

    float angle = fract(atan(d.x, -d.y) / LB_TAU);
    float into = fract(angle - start);
    float pixels = dist * LB_TAU;
    float inArc = clamp(min(into, arcLength - into) * pixels + 0.5, 0.0, 1.0);

    vec3 color = mix(LB_LS_TRACK, LB_LS_VERMILION, inArc);
    return vec4(color * band, band);
}

vec4 lb_loading_screen(vec2 screen, vec2 size, float coverage, float time, bool live,
                       sampler2D atlas, vec2 uvOrigin, vec2 uvSize) {
    float fade = lb_ls_ease(coverage);
    if (fade <= 0.0) return vec4(0.0);

    vec3 color = lb_ls_background(screen, size, time);

    vec2 centre = size * 0.5;
    float logoHeight = size.y * LB_LS_LOGO_HEIGHT;
    vec2 logoCentre = vec2(centre.x, centre.y - size.y * LB_LS_LOGO_GAP - logoHeight * 0.5);
    vec4 logo = lb_ls_logo(screen, logoCentre, logoHeight, atlas, uvOrigin, uvSize);
    color = color * (1.0 - logo.a) + logo.rgb;

    vec2 spinnerCentre = vec2(centre.x, centre.y + size.y * LB_LS_SPINNER_Y);
    vec4 spinner = lb_ls_spinner(screen, spinnerCentre, size.y * LB_LS_SPINNER_R,
                                 max(size.y * LB_LS_SPINNER_W, 2.0), time, live);
    color = color * (1.0 - spinner.a) + spinner.rgb;

    return vec4(color, fade);
}

// ---------------------------------------------------------------------------
// 7 - Bare spinner
//   Small centred spinner, nothing else. Always spinning.
// ---------------------------------------------------------------------------
vec4 lb_style_spinner(vec2 p, vec2 gui, float progress, vec3 col, float time) {
    vec2 c = vec2(floor(gui.x * 0.5), floor(gui.y * 0.5));
    return lb_spin(p, c, 13.0, 3.0, col, time);
}

// ---------------------------------------------------------------------------
// Dispatcher
// ---------------------------------------------------------------------------
vec4 lb_render(int style, vec2 guiCoord, vec2 gui, float progress, float hueByte, float time) {
    vec2 p = floor(guiCoord) + 0.5;
    vec3 col = lb_accent(hueByte, time);
    progress = clamp(progress, 0.0, 1.0);

    if (style == 1) return lb_style_classic(p, gui, progress, col, time);
    if (style == 2) return lb_style_segments(p, gui, progress, col, time);
    if (style == 3) return lb_style_top(p, gui, progress, col, time);
    if (style == 4) return lb_style_ring(p, gui, progress, col, time);
    if (style == 5) return lb_style_marquee(p, gui, progress, col, time);
    if (style == 7) return lb_style_spinner(p, gui, progress, col, time);
    return vec4(0.0);
}
