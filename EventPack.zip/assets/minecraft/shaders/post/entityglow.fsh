#version 330

// --- Tweak these ---
// Warm tint color mixed into edge and interior
#define TintR 1.0
#define TintG 0.75
#define TintB 0.3
// 0.0 = pure team color on edge, 1.0 = full tint
#define TintStrength 0.25
// Interior fill opacity — 0.0 disables fill, 1.0 = solid
#define TintAlpha 0.15
// -------------------

layout(std140) uniform SamplerInfo {
  vec2 OutSize;
  vec2 InSize;
};

uniform sampler2D InSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 oneTexel = 1.0 / InSize;
    vec3 tintColor = vec3(TintR, TintG, TintB);
    vec4 mc = texture(InSampler, texCoord);

    // Interior entity pixels: subtle warm tint overlay
    if (mc.a > 0.5) {
        vec3 tinted = mix(mc.rgb, tintColor, TintStrength);
        fragColor = vec4(tinted, TintAlpha);
        return;
    }

    // Sobel edge detection on alpha channel for crisp outline
    vec4 tl = texture(InSampler, texCoord + vec2(-1.0,  1.0) * oneTexel);
    vec4 tc = texture(InSampler, texCoord + vec2( 0.0,  1.0) * oneTexel);
    vec4 tr = texture(InSampler, texCoord + vec2( 1.0,  1.0) * oneTexel);
    vec4 ml = texture(InSampler, texCoord + vec2(-1.0,  0.0) * oneTexel);
    vec4 mr = texture(InSampler, texCoord + vec2( 1.0,  0.0) * oneTexel);
    vec4 bl = texture(InSampler, texCoord + vec2(-1.0, -1.0) * oneTexel);
    vec4 bc = texture(InSampler, texCoord + vec2( 0.0, -1.0) * oneTexel);
    vec4 br = texture(InSampler, texCoord + vec2( 1.0, -1.0) * oneTexel);

    float Gx = (-tl.a - 2.0*ml.a - bl.a) + (tr.a + 2.0*mr.a + br.a);
    float Gy = (-tl.a - 2.0*tc.a - tr.a) + (bl.a + 2.0*bc.a + br.a);
    float edge = sqrt(Gx * Gx + Gy * Gy);

    if (edge > 0.3) {
        vec4 acc = vec4(0.0);
        float w = 0.0;
        if (tl.a > 0.5) { acc += tl; w += 1.0; }
        if (tc.a > 0.5) { acc += tc; w += 1.0; }
        if (tr.a > 0.5) { acc += tr; w += 1.0; }
        if (ml.a > 0.5) { acc += ml; w += 1.0; }
        if (mr.a > 0.5) { acc += mr; w += 1.0; }
        if (bl.a > 0.5) { acc += bl; w += 1.0; }
        if (bc.a > 0.5) { acc += bc; w += 1.0; }
        if (br.a > 0.5) { acc += br; w += 1.0; }
        if (w > 0.0) {
            vec3 edgeColor = mix((acc / w).rgb, tintColor, TintStrength);
            fragColor = vec4(edgeColor, 1.0);
        } else {
            fragColor = vec4(0.0);
        }
    } else {
        fragColor = vec4(0.0);
    }
}
