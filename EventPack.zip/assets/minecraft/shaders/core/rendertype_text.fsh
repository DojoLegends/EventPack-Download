#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:loading_bars.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

flat in int lbStyle;
flat in float lbProgress;
flat in float lbHue;
flat in float lbAlpha;
flat in vec2 lbGuiSize;
flat in vec2 lbUvOrigin;
flat in vec2 lbUvSize;

out vec4 fragColor;

void main() {
    if (lbStyle > 0) {
        // gl_FragCoord is bottom-up; the GUI grid is top-down.
        vec2 guiCoord = vec2(gl_FragCoord.x / ScreenSize.x,
                             1.0 - gl_FragCoord.y / ScreenSize.y) * lbGuiSize;

        // GameTime is (ticks + partial) % 24000 / 24000 -> seconds.
        float time = GameTime * 1200.0;

        vec4 bar = lb_render(lbStyle, guiCoord, lbGuiSize, lbProgress, lbHue, time,
                             Sampler0, lbUvOrigin, lbUvSize);
        bar.a *= lbAlpha * ColorModulator.a;
        if (bar.a <= 0.0) {
            discard;
        }
        fragColor = bar;
        return;
    }

    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance,
                          FogEnvironmentalStart, FogEnvironmentalEnd,
                          FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
