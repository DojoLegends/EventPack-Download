#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:loading_bars.glsl>
#include <minecraft:plate_effects.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

layout(location = 4) flat in int lbStyle;
layout(location = 5) flat in float lbProgress;
layout(location = 6) flat in float lbHue;
layout(location = 7) flat in float lbAlpha;
layout(location = 8) flat in vec2 lbGuiSize;
layout(location = 9) flat in vec2 lbUvOrigin;
layout(location = 10) flat in vec2 lbUvSize;
layout(location = 11) in vec2 lbScreenUv;
layout(location = 12) flat in vec3 peColor;
layout(location = 13) flat in vec3 peShape;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    if (lbStyle > 0) {
        // 0..1 across the screen from the top left, interpolated from the
        // expanded quad, so it does not depend on the backend's gl_FragCoord.
        vec2 guiCoord = lbScreenUv * lbGuiSize;

        // GameTime is (ticks + partial) % 24000 / 24000 -> seconds.
        float time = GameTime * 1200.0;
        float fade = lbAlpha * ColorModulator.a;

        vec4 bar;
        if (lbStyle == LB_STYLE_LOADING_SCREEN) {
            vec2 screen = lbScreenUv * ScreenSize;
            // With no world loaded (vanilla connecting screens) GameTime is held at 0.
            bar = lb_loading_screen(screen, ScreenSize, fade, time, GameTime > 0.0, Sampler0, lbUvOrigin, lbUvSize);
        } else if (lbStyle > PE_STYLE_BASE) {
            bar = pe_render(lbStyle, lbScreenUv * peShape.xy, peShape.xy, peShape.z, peColor, time);
            bar.a *= fade;
        } else {
            bar = lb_render(lbStyle, guiCoord, lbGuiSize, lbProgress, lbHue, time);
            bar.a *= fade;
        }
        if (bar.a <= 0.0) {
            discard;
        }
        #ifdef OIT_ALPHA_ONLY
        executeAlphaOnlyPhase(gl_FragCoord.z, bar.a);
        #else
        fragColor = bar;
        #endif
        return;
    }

    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
