#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:plate_effects.glsl>

// Marker alpha baked into the top-left 2x2 texels of
// assets/minecraft/textures/font/loading_screen.png.
#define LB_MARKER 250
// The copy of the glyph in the default font, for vanilla screens whose text
// cannot be coloured: it always means the loading screen.
#define LB_MARKER_AUTO 251
// The Disconnect label (menu.disconnect). On the server-switching screen it
// becomes the loading screen, covering the button it labels; anywhere else it
// draws the word "Disconnect" from texels baked into the same glyph.
#define LB_MARKER_LABEL 252
#define LB_LABEL_ORIGIN vec2(2.0, 240.0)
#define LB_LABEL_SIZE vec2(53.0, 8.0)
// The glyph's quad in GUI pixels (the font provider's height).
#define LB_GLYPH_GUI 8.0
// ServerReconfigScreen centres its title with the button below it, so the
// label sits a little under the middle of the screen. Other screens with no
// world and a Disconnect button (resource pack prompt, code of conduct) keep
// their buttons lower down and are left alone.
#define LB_LABEL_COVER_ABOVE 4.0
#define LB_LABEL_COVER_BELOW 40.0
#define LB_MAX_STYLE 7
#define LB_STYLE_LOADING_SCREEN 6

// Source size of that texture. Bitmap glyphs are stored in the font atlas at
// their source resolution, so this gives us the glyph's atlas rectangle without
// having to guess where the atlas packer put it. Must match LB_GLYPH_PX in
// shaders/include/loading_bars.glsl and SIZE in tools/bake_logo.py.
#define LB_GLYPH_PX 252.0

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

layout(location = 4) flat out int lbStyle;
layout(location = 5) flat out float lbProgress;
layout(location = 6) flat out float lbHue;
layout(location = 7) flat out float lbAlpha;
layout(location = 8) flat out vec2 lbGuiSize;
layout(location = 9) flat out vec2 lbUvOrigin;
layout(location = 10) flat out vec2 lbUvSize;
layout(location = 11) out vec2 lbScreenUv;
layout(location = 12) flat out vec3 peColor;
layout(location = 13) flat out vec3 peShape;

// Glyph quad corners in GUI space (y down): top left, bottom left, bottom
// right, top right.
const vec2[4] LB_CORNERS = vec2[4](
    vec2(0.0, 0.0), vec2(0.0, 1.0), vec2(1.0, 1.0), vec2(1.0, 0.0)
);

int lb_marker(vec2 uv) {
    return int(round(textureLod(Sampler0, uv, 0.0).a * 255.0));
}

// Which corner of a loading glyph this vertex is, worked out from the atlas
// rather than gl_VertexIndex: only the true corner puts the glyph's origin on
// the 2x2 marker block. Returns the marker, or 0 for every other glyph.
// Where this label vertex's glyph is centred, in GUI pixels.
vec2 lb_glyph_centre(vec2 corner) {
    return Position.xy + (0.5 - corner) * LB_GLYPH_GUI;
}

// Only with no world loaded (GameTime is held at 0) and only where the
// server-switching screen puts its button.
bool lb_label_covers(vec2 corner, vec2 guiSize) {
    float below = lb_glyph_centre(corner).y - guiSize.y * 0.5;
    return GameTime <= 0.0 && below > -LB_LABEL_COVER_ABOVE && below < LB_LABEL_COVER_BELOW;
}

// Reshape the glyph into a label-sized quad around its centre, textured from
// the baked "Disconnect" texels, and leave it to be drawn as ordinary text.
void lb_draw_label(vec2 corner, vec2 uvOrigin, vec2 uvSize) {
    vec2 position = lb_glyph_centre(corner) + (corner - 0.5) * LB_LABEL_SIZE;
    gl_Position = ProjMat * ModelViewMat * vec4(position, Position.z, 1.0);
    texCoord0 = uvOrigin + (LB_LABEL_ORIGIN + corner * LB_LABEL_SIZE) / LB_GLYPH_PX * uvSize;
}

int lb_find_corner(vec2 uv, vec2 uvSize, vec2 texel, out vec2 corner) {
    for (int i = 0; i < 4; i++) {
        vec2 origin = uv - LB_CORNERS[i] * uvSize;
        if (any(lessThan(origin, -texel)) || any(greaterThan(origin + uvSize, vec2(1.0) + texel))) {
            continue;
        }
        int marker = lb_marker(origin + texel * 0.5);
        if (marker >= LB_MARKER && marker <= LB_MARKER_LABEL && lb_marker(origin + texel * 1.5) == marker) {
            corner = LB_CORNERS[i];
            return marker;
        }
    }
    corner = vec2(0.0);
    return 0;
}

bool pe_find(vec2 uv, vec2 texel, out vec2 corner, out int effect, out float height, out float topOffset) {
    vec2 uvSize = PE_CELL_PX * texel;
    for (int i = 0; i < 4; i++) {
        vec2 origin = uv - LB_CORNERS[i] * uvSize;
        if (any(lessThan(origin, -texel)) || any(greaterThan(origin + uvSize, vec2(1.0) + texel))) {
            continue;
        }
        if (lb_marker(origin + texel * vec2(0.5, 0.5)) == PE_MARKER
                && lb_marker(origin + texel * vec2(1.5, 0.5)) == PE_MARKER
                && lb_marker(origin + texel * vec2(0.5, 1.5)) == PE_MARKER
                && lb_marker(origin + texel * vec2(1.5, 1.5)) == PE_MARKER) {
            corner = LB_CORNERS[i];
            effect = lb_marker(origin + texel * vec2(0.5, 2.5));
            height = float(lb_marker(origin + texel * vec2(1.5, 2.5)));
            topOffset = float(lb_marker(origin + texel * vec2(0.5, 3.5)));
            return true;
        }
    }
    corner = vec2(0.0);
    effect = 0;
    height = 0.0;
    topOffset = 0.0;
    return false;
}

// Stretches a plate effect glyph over the plate it was placed on. Returns
// false for every other glyph.
bool pe_apply(vec2 texel) {
    vec2 corner;
    int effect;
    float height;
    float topOffset;
    if (!pe_find(UV0, texel, corner, effect, height, topOffset)) {
        return false;
    }
    ivec3 rgb = ivec3(round(Color.rgb * 255.0));
    float width = float(((rgb.g & 1) << 8) | rgb.b);
    bool valid = effect >= PE_EFFECT_FLASH && effect <= PE_EFFECT_ENCIRCLE && width >= 3.0 && height >= 3.0;
    if (!valid || ProjMat[3][3] != 1.0 || Color.a <= 0.0) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        return true;
    }

    lbStyle = PE_STYLE_BASE + effect;
    lbAlpha = Color.a;
    lbScreenUv = corner;
    peColor = vec3(float(rgb.r >> 4), float(rgb.r & 15), float(rgb.g >> 4)) / 15.0;
    peShape = vec3(width, height, PE_PERIODS[(rgb.g >> 1) & 7]);

    vec2 plateOrigin = Position.xy - corner * PE_CELL_PX + vec2(0.0, topOffset);
    gl_Position = ProjMat * ModelViewMat * vec4(plateOrigin + corner * peShape.xy, Position.z, 1.0);
    return true;
}

void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

    lbStyle = 0;
    lbProgress = 0.0;
    lbHue = 0.0;
    lbAlpha = 1.0;
    lbGuiSize = vec2(1.0);
    lbUvOrigin = vec2(0.0);
    lbUvSize = vec2(1.0);
    lbScreenUv = vec2(0.0);
    peColor = vec3(0.0);
    peShape = vec3(1.0);

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
    vec2 uvSize = LB_GLYPH_PX * texel;
    vec2 corner;
    int marker = lb_find_corner(UV0, uvSize, texel, corner);
    if (marker == 0) {
        pe_apply(texel);
        return;
    }
    vec2 uvOrigin = UV0 - corner * uvSize;

    // From here on this vertex belongs to a loading-screen glyph and must never
    // be drawn as normal text.

    // Only ever expand in an orthographic (GUI) pass.
    if (ProjMat[3][3] != 1.0) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        return;
    }

    vec2 guiSize = abs(vec2(2.0 / ProjMat[0][0], 2.0 / ProjMat[1][1]));
    if (marker == LB_MARKER_LABEL && !lb_label_covers(corner, guiSize)) {
        lb_draw_label(corner, uvOrigin, uvSize);
        return;
    }

    // Red channel carries 128 + style. Vanilla's text shadow is (rgb & 0xFCFCFC) >> 2,
    // so a shadow copy can never reach 128 and is rejected here.
    int red = int(round(Color.r * 255.0));
    bool alwaysLoading = marker != LB_MARKER;
    int style = alwaysLoading ? LB_STYLE_LOADING_SCREEN : red - 128;
    if ((!alwaysLoading && red < 128) || style < 1 || style > LB_MAX_STYLE || Color.a <= 0.0) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        return;
    }

    lbStyle = style;
    lbProgress = round(Color.g * 255.0) / 255.0;
    lbHue = round(Color.b * 255.0);
    // Follow the text's own alpha so action bar / chat fade-outs fade it too.
    lbAlpha = Color.a;
    lbUvOrigin = uvOrigin;
    lbUvSize = uvSize;

    // Orthographic GUI projection, so 2 / its scale is the GUI size. Which way
    // y runs depends on the backend, hence abs.
    lbGuiSize = guiSize;
    lbScreenUv = corner;

    // Stretch the glyph over the whole GUI, through the same projection as
    // every other glyph so the quad keeps vanilla's orientation and winding on
    // both OpenGL and Vulkan. The glyph's own depth is kept so the overlay
    // still layers correctly against the rest of the GUI.
    float depth = gl_Position.z;
    gl_Position = ProjMat * vec4(corner * lbGuiSize, 0.0, 1.0);
    gl_Position.z = depth;
}
