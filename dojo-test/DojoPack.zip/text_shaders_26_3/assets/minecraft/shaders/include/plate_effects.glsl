#define O29 23
#define O23 vec2(2.0, 64.0)
#define O2a 4.0
#define O25 1
#define O24 2
#define O2b 15
#define O2d (O2b + O25)
#define O2c (O2b + O24)
const float PE_PERIODS[8] = float[8](4.0, 3.0, 2.0, 1.5, 1.0, 0.75, 0.5, 0.25);
#define O26 0.25
#define O28 4.0
#define O27 32.0
float O79(vec2 p, vec2 size) {
float right = size.x - 1.0;
float bottom = size.y - 1.0;
float across = size.x - 2.0;
float down = size.y - 2.0;
bool onTop = p.y == 0.0;
bool onBottom = p.y == bottom;
bool onLeft = p.x == 0.0;
bool onRight = p.x == right;
if ((onTop || onBottom) && (onLeft || onRight)) return -1.0;
if (onTop) return p.x - 1.0;
if (onRight) return across + p.y - 1.0;
if (onBottom) return across + down + (right - 1.0 - p.x);
if (onLeft) return 2.0 * across + down + (bottom - 1.0 - p.y);
return -1.0;
}
float O78(vec2 size) {
return 2.0 * (size.x - 2.0) + 2.0 * (size.y - 2.0);
}
vec4 O74(float period, vec3 colour, float time) {
return fract(time / period) < 0.5 ? vec4(colour, 1.0) : vec4(0.0);
}
vec4 O72(float s, vec2 size, float period, vec3 colour, float time) {
float lap = O78(size);
float head = floor(fract(time / period) * lap);
float behind = mod(head - s + lap, lap);
float segment = clamp(floor(lap * O26), O28, O27);
return behind < segment ? vec4(colour, 1.0) : vec4(0.0);
}
vec4 O71(int style, float s, vec2 size, float period, vec3 colour, float time) {
if (style == O2d) return O74(period, colour, time);
if (style == O2c) return O72(s, size, period, colour, time);
return vec4(0.0);
}
bool O75(vec2 p, vec2 size) {
return (p.x == 1.0 || p.x == size.x - 2.0) && (p.y == 1.0 || p.y == size.y - 2.0);
}
vec4 O76(int style, vec2 local, vec2 size, float period, vec3 colour, float time) {
vec2 p = floor(local);
if (any(lessThan(p, vec2(0.0))) || any(greaterThanEqual(p, size))) return vec4(0.0);
float s = O79(p, size);
if (s >= 0.0) return O71(style, s, size, period, colour, time);
if (!O75(p, size)) return vec4(0.0);
vec2 edge = vec2(p.x == 1.0 ? 0.0 : size.x - 1.0, p.y == 1.0 ? 0.0 : size.y - 1.0);
vec4 alongEdge = O71(style, O79(vec2(p.x, edge.y), size), size, period, colour, time);
if (alongEdge.a > 0.0) return alongEdge;
return O71(style, O79(vec2(edge.x, p.y), size), size, period, colour, time);
}
vec4 O77(int style, vec2 position, vec3 topLeft, vec3 bottomRight, vec4 shape, vec3 colour, float time) {
if (topLeft.z <= 0.0 || bottomRight.z <= 0.0) return vec4(0.0);
vec2 origin = topLeft.xy / topLeft.z;
vec2 scale = (bottomRight.xy / bottomRight.z - origin) / O23;
vec2 local = (position - origin) / scale - vec2(0.0, shape.w);
return O76(style, local, shape.xy, shape.z, colour, time);
}
