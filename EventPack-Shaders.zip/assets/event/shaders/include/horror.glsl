#ifndef O21
#define O21
#include <event:post_common.glsl>
float Of3() {
float t = mod(Oe2(), 32.0);
float first = exp(-t * 0.35);
float second = t >= 6.0 ? 0.7 * exp(-(t - 6.0) * 0.35) : 0.0;
return clamp(first + second, 0.0, 1.0);
}
#define O2f 0.05
float Of2(float depth) {
return depth <= 0.0 ? 100000.0 : O2f / depth;
}
#endif
