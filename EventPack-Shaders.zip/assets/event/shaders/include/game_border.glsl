#ifndef O1f
#define O1f
#define O4 254.0
#define O5 176
#define Oa 1
#define O7 4
#define O6 8
#define O8 16
#define O9 64.0
#define O3 0.06
#define O2 3.0
int Obc(vec4 texel) {
ivec4 value = ivec4(round(texel * 255.0));
if (value.a != int(O4) || (value.r & 3) != 2 || (value.g & 3) != 2) {
return -1;
}
int flags = value.b - O5;
return flags >= 0 && flags < 32 ? flags : -1;
}
vec3 Oc4(vec3 position) {
return position + vec3(CameraBlockPos) - CameraOffset;
}
vec2 Oc1(vec4 texel, vec2 atlasUv, vec2 atlasSize) {
vec2 index = floor(texel.rg * 255.0 / (256.0 / O9));
vec2 atlasTexel = atlasUv * atlasSize;
vec2 corner = floor(atlasTexel - vec2(index.x, O9 - 1.0 - index.y));
vec2 local = (atlasTexel - corner) / O9;
return vec2(local.x, 1.0 - local.y);
}
struct BorderDerivatives {
vec2 panelDx;
vec2 panelDy;
vec3 worldDx;
vec3 worldDy;
};
BorderDerivatives Oba(vec2 atlasUv, vec2 atlasSize, vec3 view) {
vec2 atlasTexel = atlasUv * atlasSize / O9;
vec2 flipV = vec2(1.0, -1.0);
return BorderDerivatives(dFdx(atlasTexel) * flipV, dFdy(atlasTexel) * flipV, dFdx(view), dFdy(view));
}
bool Ob9(BorderDerivatives d, vec3 bakedNormal, vec3 view) {
vec3 normal = cross(d.worldDx, d.worldDy);
if (dot(normal, bakedNormal) < 0.0) {
normal = -normal;
}
return dot(normal, view) > 0.0;
}
bool Oc3(vec3 tint) {
return (int(round(tint.b * 255.0)) & 1) != 0;
}
float Oc2(vec2 gradient, vec2 dx, vec2 dy) {
return max(length(vec2(dot(gradient, dx), dot(gradient, dy))), 1e-6);
}
float Oc0(float pixels, float widthPixels) {
return 1.0 - smoothstep(widthPixels, widthPixels + 1.0, pixels);
}
float Obd(vec2 p) {
return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}
vec2 Obe(vec2 p, vec2 dx, vec2 dy, float lineWidth, float seconds) {
const vec2 cell = vec2(1.0, 1.7320508);
const vec2 diagonal = vec2(0.5, 0.8660254);
vec2 centreA = floor(p / cell) * cell + cell * 0.5;
vec2 centreB = floor((p - cell * 0.5) / cell) * cell + cell;
vec2 a = p - centreA;
vec2 b = p - centreB;
bool inA = dot(a, a) < dot(b, b);
vec2 offset = inA ? a : b;
vec2 g = abs(offset);
vec2 side = dot(g, diagonal) > g.x ? diagonal * sign(offset) : vec2(sign(offset.x), 0.0);
float edge = 0.5 - dot(offset, side);
float pixels = abs(edge) / Oc2(side, dx, dy);
float shimmer = pow(0.5 + 0.5 * sin(seconds * 1.3 + Obd(inA ? centreA : centreB) * 6.2831), 6.0);
return vec2(Oc0(pixels, lineWidth), shimmer);
}
vec2 Obf(vec3 worldPos, BorderDerivatives d, vec3 normal, float scale, float lineWidth, float seconds) {
vec3 n = normalize(normal);
vec3 tangent = normalize(cross(abs(n.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0), n));
vec3 bitangent = cross(n, tangent);
mat2x3 basis = mat2x3(tangent, bitangent);
vec2 p = worldPos * basis * scale;
return Obe(p, d.worldDx * basis * scale, d.worldDy * basis * scale, lineWidth, seconds);
}
vec4 Obb(int flags, vec2 panel, BorderDerivatives d, vec3 worldPos, vec3 normal, vec3 tint, float viewDistance, float seconds) {
bool triangle = (flags & Oa) != 0;
bool seamless = (flags & O8) != 0;
bool plain = Oc3(tint);
float hypotenuse = 1.0 - panel.x - panel.y;
if (triangle && hypotenuse < 0.0) {
return vec4(0.0);
}
float blocksPerPixel = max(length(abs(d.worldDx) + abs(d.worldDy)), 1e-4);
float width = max(1.0, O3 / blocksPerPixel);
float uPixel = Oc2(vec2(1.0, 0.0), d.panelDx, d.panelDy);
float vPixel = Oc2(vec2(0.0, 1.0), d.panelDx, d.panelDy);
float edgePixels = 1e6;
if (!seamless) {
if (triangle) {
if ((flags & O6) == 0) edgePixels = min(edgePixels, panel.y / vPixel);
if ((flags & O7) == 0) edgePixels = min(edgePixels, hypotenuse / Oc2(vec2(1.0), d.panelDx, d.panelDy));
} else {
edgePixels = min(min(panel.x, 1.0 - panel.x) / uPixel, min(panel.y, 1.0 - panel.y) / vPixel);
}
}
float edge = Oc0(edgePixels, width);
bool cellFan = flags == (Oa | O7);
float glow = seamless ? 0.0 : (cellFan ? exp(-panel.y * O2) : exp(-edgePixels * blocksPerPixel * 0.9));
float near = 1.0 - smoothstep(4.0, 26.0, viewDistance);
vec2 fine = plain ? vec2(0.0) : Obf(worldPos, d, normal, 0.6, 0.6, seconds);
vec2 coarse = plain ? vec2(0.0) : Obf(worldPos, d, normal, 0.12, seamless ? 1.2 : 0.8, seconds);
float sweep = plain ? 0.0 : pow(0.5 + 0.5 * sin(dot(worldPos, vec3(0.57)) * 0.8 - seconds * 2.5), 8.0);
float breath = 0.85 + 0.15 * sin(seconds * 2.0);
vec3 deep = tint * 0.75;
vec3 rim = mix(tint, vec3(1.0), 0.35);
float hex = fine.x * near + coarse.x * (seamless ? 0.9 : 0.35);
float shimmer = coarse.y * (seamless ? 1.0 : 0.4);
float heat = clamp(edge + glow * 0.5 + hex * 0.8 + shimmer * 0.4 + sweep * 0.5, 0.0, 1.0);
vec3 color = mix(mix(deep, tint, heat) * (1.0 + hex * 0.09), rim, edge);
float alpha = 0.12 + edge * 0.6 + glow * 0.18 + near * 0.16 + hex * 0.4 + shimmer * 0.12 + sweep * 0.12;
alpha *= breath * smoothstep(0.05, 0.35, viewDistance);
return vec4(color, clamp(alpha, 0.0, 0.9));
}
#endif
