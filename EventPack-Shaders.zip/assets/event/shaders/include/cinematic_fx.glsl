#ifndef O1e
#define O1e
#include <event:game_border.glsl>
#include <event:post_common.glsl>
#define O13 253
#define O14 200
#define O18 1
#define O15 2
#define O11 3
#define O10 4
#define O12 12.0
#define Oe 12
#define O17 6
#define O16 0.3
#define Of 3
int Ocd(vec4 texel) {
ivec4 value = ivec4(round(texel * 255.0));
if (value.a != O13 || (value.r & 3) != 2 || (value.g & 3) != 2) {
return -1;
}
int kind = value.b - O14;
return kind >= O18 && kind <= O10 ? kind : -1;
}
float Oce(vec2 p) {
vec2 i = floor(p);
vec2 f = fract(p);
f = f * f * (3.0 - 2.0 * f);
return mix(
mix(Odb(i), Odb(i + vec2(1.0, 0.0)), f.x),
mix(Odb(i + vec2(0.0, 1.0)), Odb(i + 1.0), f.x),
f.y
);
}
float Oc7(vec2 p) {
return 0.55 * Oce(p) + 0.3 * Oce(p * 2.1 + 7.3) + 0.15 * Oce(p * 4.3 + 3.1);
}
vec2 Od1(vec2 p, vec2 a, vec2 b) {
vec2 ab = b - a;
float h = clamp(dot(p - a, ab) / max(dot(ab, ab), 1e-8), 0.0, 1.0);
return vec2(length(p - a - ab * h), h);
}
float Oc6(BorderDerivatives d, vec3 view) {
vec3 normal = cross(d.worldDx, d.worldDy);
float size = length(normal) * length(view);
return size > 1e-12 ? abs(dot(normal, view)) / size : 1.0;
}
vec4 Ocf(vec4 under, vec3 colour, float alpha) {
float a = alpha + under.a * (1.0 - alpha);
vec3 rgb = (colour * alpha + under.rgb * under.a * (1.0 - alpha)) / max(a, 1e-5);
return vec4(rgb, a);
}
vec3 Oc8(vec3 tint, float heat) {
vec3 hot = mix(tint, vec3(1.0, 0.96, 0.85), 0.8);
vec3 fire = mix(tint * 0.45, tint, smoothstep(0.1, 0.5, heat));
return mix(fire, hot, smoothstep(0.5, 0.9, heat));
}
vec4 Od4(vec2 p, float facing, vec3 tint, float seconds) {
float along = p.y;
float across = abs(p.x - 0.5) * 2.0;
float n = Oc7(vec2(p.x * 4.0, along * 5.0 - seconds * 6.0));
float n2 = Oc7(vec2(p.x * 9.0 + 3.0, along * 11.0 - seconds * 11.0));
float flicker = 0.9 + 0.1 * Ode(seconds * 12.0);
float width = mix(0.9, 0.12, sqrt(along)) * flicker * (0.75 + 0.5 * n);
float body = 1.0 - smoothstep(width * 0.35, width, across);
float reach = 0.6 + 0.35 * n2;
float flame = body * (1.0 - smoothstep(reach * 0.5, reach, along));
float heat = flame * (1.0 - along) * (1.2 - across);
float head = exp(-along * 14.0) * (1.0 - smoothstep(0.2, 0.9, across));
float smokeWidth = mix(0.5, 1.0, along) * (0.7 + 0.6 * n);
float smoke = (1.0 - smoothstep(smokeWidth * 0.3, smokeWidth, across))
* smoothstep(0.3, 0.7, along) * (1.0 - smoothstep(0.75, 1.0, along)) * 0.35 * n;
vec4 colour = vec4(vec3(0.16, 0.13, 0.12), smoke);
colour = Ocf(colour, Oc8(tint, heat + head), clamp(flame * (0.35 + heat) + head, 0.0, 1.0));
colour.a *= smoothstep(0.15, 0.6, facing);
return colour;
}
vec4 Od2(vec2 p, float pixel, float seconds) {
vec3 light = vec3(0.0);
float alpha = 0.0;
for (int i = 0; i < O17; i++) {
float slot = float(i);
float period = 2.6 + 1.7 * Odc(slot + 0.37);
float phase = seconds / period + Odc(slot + 5.1);
float life = fract(phase) / O16;
vec2 seed = vec2(slot * 13.7, floor(phase));
if (life > 1.0 || Odb(seed) > 0.75) {
continue;
}
vec2 start = vec2(0.12 + 0.76 * Odb(seed + 1.3), 0.45 + 0.45 * Odb(seed + 2.9));
float side = Odb(seed + 4.1) < 0.5 ? -1.0 : 1.0;
float angle = -O24 * 0.5 + side * (0.35 + 0.75 * Odb(seed + 6.7));
vec2 dir = vec2(cos(angle), sin(angle));
float travel = 0.22 + 0.2 * Odb(seed + 8.2);
vec2 head = start + dir * travel * (1.0 - (1.0 - life) * (1.0 - life));
float tail = travel * 0.45 * sin(O24 * min(life * 1.4, 1.0)) + pixel;
vec2 d = Od1(p, head - dir * tail, head);
float width = max(pixel * 0.9, 0.0018);
float line = (1.0 - smoothstep(0.0, width, d.x)) * d.y * d.y;
float glow = exp(-d.x / (width * 3.0)) * d.y * d.y * d.y * 0.35;
float k = (line + glow) * sin(O24 * life);
light += mix(vec3(0.75, 0.85, 1.0), vec3(1.0), d.y) * k;
alpha += k;
}
return vec4(light / max(alpha, 1e-5), clamp(alpha, 0.0, 1.0));
}
vec4 Oc9(vec2 p, vec3 tint, float seconds) {
vec4 colour = vec4(0.0);
for (int i = 0; i < Of; i++) {
float slot = float(i);
float period = 10.0 + 6.0 * Odc(slot + 2.3);
float phase = seconds / period + Odc(slot + 9.4);
float life = fract(phase);
vec2 seed = vec2(slot * 7.9 + 40.0, floor(phase));
float side = Odb(seed + 0.7) < 0.5 ? -1.0 : 1.0;
vec2 start = vec2(side < 0.0 ? 1.1 : -0.1, 0.7 + 0.25 * Odb(seed + 1.9));
vec2 dir = normalize(vec2(-side, -(0.25 + 0.35 * Odb(seed + 3.1))));
vec2 head = start + dir * 1.4 * life;
float size = 0.006 + 0.006 * Odb(seed + 5.3);
float tailLength = 0.22 + 0.1 * Odb(seed + 7.7);
vec2 d = Od1(p, head - dir * tailLength, head);
float n = Oc7(vec2(d.y * 8.0 - seconds * 6.0, d.x / size * 0.5 + slot * 3.0));
float tailWidth = size * mix(0.3, 1.0, d.y) * (0.7 + 0.6 * n);
float body = (1.0 - smoothstep(tailWidth * 0.4, tailWidth, d.x)) * pow(d.y, 1.5);
float halo = exp(-length(p - head) / (size * 1.5));
float fade = smoothstep(0.0, 0.05, life) * (1.0 - smoothstep(0.9, 1.0, life));
colour = Ocf(colour, Oc8(tint, d.y * 0.7 + halo), clamp((body * 0.8 + halo) * fade, 0.0, 1.0));
}
return colour;
}
vec4 Od3(vec2 p, float pixel, vec3 tint, float seconds) {
vec4 colour = Od2(p, pixel, seconds);
vec4 fireballs = Oc9(p, tint, seconds);
colour = Ocf(colour, fireballs.rgb, fireballs.a);
vec2 edge = min(p, 1.0 - p);
colour.a *= smoothstep(0.0, 0.08, min(edge.x, edge.y));
return colour;
}
float Occ(vec3 tint) {
return fract(GameTime - Od7(tint) + 1.0) * 1200.0;
}
vec4 Ocb(vec2 p, float t) {
vec2 c = (p - 0.5) * 2.0;
float r = length(c);
float angle = atan(c.y, c.x);
float n = Oc7(vec2(angle * 3.0, r * 6.0 - t * 2.0));
float front = 1.0 - exp(-t * 1.4);
float wobble = (n - 0.5) * 0.08;
float width = 0.03 + 0.08 * front;
float edge = (1.0 - smoothstep(0.0, width, abs(r - front + wobble))) * (1.0 - smoothstep(2.5, 5.0, t));
float heat = (1.0 - smoothstep(0.0, width * 3.0, front - wobble - r)) * step(r, front + wobble) * exp(-t * 1.2);
float dust = step(r, front + wobble + 0.04) * smoothstep(front - 0.7, front, r) * (0.45 + 0.75 * n)
* (1.0 - smoothstep(1.5, 6.5, t));
float crater = 1.0 - smoothstep(0.18, 0.42, r + (n - 0.5) * 0.15);
float scorch = crater * smoothstep(0.0, 0.3, t) * (1.0 - smoothstep(8.0, O12, t));
float cracks = (1.0 - smoothstep(0.0, 0.05, abs(Oc7(c * 5.0 + 11.0) - 0.5))) * crater;
float embers = cracks * (0.6 + 0.4 * Ode(t * 3.0 + c.x * 9.0)) * (1.0 - smoothstep(2.0, 10.0, t));
float flash = (1.0 - smoothstep(0.0, 0.3 + t * 2.0, r)) * exp(-t * 5.0);
vec4 colour = vec4(vec3(0.06, 0.045, 0.035), scorch * 0.9);
colour = Ocf(colour, vec3(1.0, 0.45, 0.1), clamp(embers * 1.4, 0.0, 1.0));
colour = Ocf(colour, vec3(0.5, 0.4, 0.31), clamp(dust * 0.8, 0.0, 1.0));
colour = Ocf(colour, vec3(1.0, 0.55, 0.2), heat * 0.6);
colour = Ocf(colour, vec3(1.0, 0.9, 0.7), edge);
colour = Ocf(colour, vec3(1.0, 0.97, 0.9), clamp(flash, 0.0, 1.0));
colour.a *= 1.0 - smoothstep(0.9, 1.0, r);
return colour;
}
vec4 Oca(vec2 p, float facing, float t) {
vec2 q = vec2(p.x - 0.5, p.y);
float rise = smoothstep(0.4, 3.5, t);
float fade = 1.0 - smoothstep(6.0, O12, t);
float nc = Oc7(vec2(q.x * 10.0, q.y * 4.0 - t * 1.2));
float plumeTop = 0.15 + 0.6 * rise;
float columnWidth = 0.035 + 0.04 * q.y;
float column = (1.0 - smoothstep(columnWidth * 0.6, columnWidth, abs(q.x) + (nc - 0.5) * 0.05))
* (1.0 - smoothstep(plumeTop - 0.06, plumeTop, q.y));
float capRadius = 0.08 + 0.12 * rise;
float cap = 1.0 - smoothstep(0.7, 1.0, length((q - vec2(0.0, plumeTop)) * vec2(1.0, 1.7)) / capRadius + (nc - 0.5) * 0.45);
float smoke = max(column, cap) * rise * fade;
float grow = 1.0 - exp(-t * 3.5);
vec2 centre = vec2(0.0, 0.03 + 0.25 * rise);
float radius = 0.05 + 0.24 * grow - 0.08 * rise;
float nb = Oc7(q * 9.0 + vec2(0.0, -t * 0.8));
float d = length((q - centre) * vec2(1.0, 1.1)) / max(radius, 0.03) + (nb - 0.5) * 0.5;
float ball = (1.0 - smoothstep(0.75, 1.0, d)) * fade;
float heat = clamp((1.0 - d) * 1.8 * exp(-t * 0.5), 0.0, 1.0);
vec3 smokeColour = mix(vec3(0.1, 0.09, 0.09), vec3(0.4, 0.22, 0.12), exp(-t * 0.6) * (1.0 - q.y));
vec4 colour = vec4(smokeColour, smoke * 0.85);
colour = Ocf(colour, mix(smokeColour, Oc8(vec3(1.0, 0.42, 0.1), heat), smoothstep(0.02, 0.35, heat)), ball);
for (int i = 0; i < Oe; i++) {
float slot = float(i);
float launch = mix(0.3, O24 - 0.3, Odc(slot + 0.5));
float speed = 0.35 + 0.55 * Odc(slot + 7.3);
float age = t - 0.05 * Odc(slot + 3.1);
if (age <= 0.0 || age > 3.0) continue;
vec2 dir = vec2(cos(launch), sin(launch)) * speed;
float before = max(age - 0.12, 0.0);
vec2 at = dir * age - vec2(0.0, 0.3 * age * age);
vec2 was = dir * before - vec2(0.0, 0.3 * before * before);
if (at.y < 0.0) continue;
vec2 seg = Od1(q, was, at);
float spark = (1.0 - smoothstep(0.0, 0.007, seg.x)) * seg.y * exp(-age * 0.9);
colour = Ocf(colour, vec3(1.0, 0.75, 0.35), spark);
}
float flash = exp(-t * 7.0) * (1.0 - smoothstep(0.0, 0.35, length(q)));
colour = Ocf(colour, vec3(1.0, 0.97, 0.9), clamp(flash, 0.0, 1.0));
colour.a *= smoothstep(0.1, 0.5, facing) * (1.0 - smoothstep(0.42, 0.5, abs(q.x))) * (1.0 - smoothstep(0.92, 1.0, q.y));
return colour;
}
vec4 Od0(int kind, vec2 panel, BorderDerivatives d, vec3 view, vec3 tint, float seconds) {
if (kind == O18) {
return Od4(panel, Oc6(d, view), tint, seconds);
}
if (kind == O11 || kind == O10) {
float t = Occ(tint);
if (t > O12) return vec4(0.0);
return kind == O11 ? Ocb(panel, t) : Oca(panel, Oc6(d, view), t);
}
vec2 pixel = abs(d.panelDx) + abs(d.panelDy);
return Od3(panel, max(pixel.x, pixel.y), tint, seconds);
}
#endif
