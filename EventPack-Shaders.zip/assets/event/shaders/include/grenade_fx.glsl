#ifndef O20
#define O20
#include <event:post_common.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#define O2a 252
#define O2b 96
#define O25 1
#define O26 2
#define O2d 8
#define O2c 9
#define O29 1.4
#define O2e 14
#define O28 0.12
#define O27 0.7
#define O6c 480.0
#define O6b 2.0
#define O7c 0.25
#define O74 14
#define O78 0.35
#define O75 0.3
#define O7b 1.3
#define O73 -1.5
#define O71 3.0
#define O77 0.2
#define O76 0.55
#define O79 0.07
#define O6f 0.45
#define O6e 8.6
#define O6d 10.6
#define O72 vec3(0.36, 0.37, 0.4)
#define O70 vec3(0.55, 0.56, 0.59)
#define O7a 0.65
int Oeb(vec4 texel) {
ivec4 value = ivec4(round(texel * 255.0));
if (value.a != O2a || (value.r & 3) != 2 || (value.g & 3) != 2) {
return -1;
}
int kind = value.b - O2b;
bool smoke = kind == O2d || kind == O2c;
return smoke || kind == O25 || kind == O26 ? kind : -1;
}
float Oea(vec3 p) {
p = fract(p * 0.1031);
p += dot(p, p.zyx + 31.32);
return fract((p.x + p.y) * p.z);
}
float Oec(vec3 p) {
vec3 i = floor(p);
vec3 f = fract(p);
f = f * f * (3.0 - 2.0 * f);
return mix(
mix(mix(Oea(i), Oea(i + vec3(1.0, 0.0, 0.0)), f.x),
mix(Oea(i + vec3(0.0, 1.0, 0.0)), Oea(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
mix(mix(Oea(i + vec3(0.0, 0.0, 1.0)), Oea(i + vec3(1.0, 0.0, 1.0)), f.x),
mix(Oea(i + vec3(0.0, 1.0, 1.0)), Oea(i + 1.0), f.x), f.y),
f.z
);
}
vec2 Oee(vec2 p, vec2 a, vec2 b) {
vec2 ab = b - a;
float h = clamp(dot(p - a, ab) / max(dot(ab, ab), 1e-8), 0.0, 1.0);
return vec2(length(p - a - ab * h), h);
}
float Oe9(vec3 tint) {
return fract(GameTime - Od7(tint) + 1.0) * 1200.0;
}
vec4 Oe7(vec2 panel, float t) {
vec2 c = (panel - 0.5) * 2.0;
float r = length(c);
float angle = atan(c.y, c.x);
float glare = smoothstep(0.0, O28, t) * exp(-t * 4.0);
float core = exp(-pow(r / (0.07 + 0.2 * glare), 2.0)) * (0.35 + 0.65 * glare);
float halo = exp(-r / (0.1 + 0.3 * glare)) * glare;
float rays = pow(abs(cos(angle * 3.0 + 0.4)), 48.0) * exp(-r * 2.4) * glare;
float streak = exp(-abs(c.y) * 60.0) * exp(-abs(c.x) * 1.6) * glare;
float front = 0.12 + 0.85 * (1.0 - exp(-t * 5.0));
float ring = exp(-pow((r - front) / 0.03, 2.0)) * exp(-t * 4.0) * 0.7;
float sparks = 0.0;
for (int i = 0; i < O2e; i++) {
float slot = float(i);
float a = slot / float(O2e) * 2.0 * O24 + Odc(slot + 0.7) * 0.4;
float reach = (0.35 + 0.5 * Odc(slot + 3.3)) * (1.0 - exp(-t * 3.5));
vec2 dir = vec2(cos(a), sin(a));
vec2 d = Oee(c, dir * reach * 0.55, dir * reach);
float life = exp(-t * (2.0 + 1.5 * Odc(slot + 9.1)));
sparks += (1.0 - smoothstep(0.0, 0.012, d.x)) * d.y * life;
}
float light = core + halo * 0.9 + rays * 0.8 + streak * 0.7 + ring;
vec3 colour = mix(vec3(0.78, 0.85, 0.95), vec3(0.97, 0.94, 0.86), clamp(core * 1.5, 0.0, 1.0));
colour = mix(colour, vec3(1.0, 0.9, 0.72), clamp(sparks, 0.0, 1.0) * (1.0 - clamp(core, 0.0, 1.0)));
float alpha = clamp(light + sparks * 0.9, 0.0, 1.0) * (1.0 - smoothstep(0.85, 1.0, r)) * O27;
return vec4(colour, alpha);
}
vec4 Oe8(vec2 panel, float t) {
vec2 c = (panel - 0.5) * 2.0;
float r = length(c);
float glare = smoothstep(0.0, O28, t) * exp(-t * 5.0);
float pool = exp(-r * r / 0.2) * glare;
float front = 0.1 + 0.8 * (1.0 - exp(-t * 6.0));
float edge = exp(-pow((r - front) / 0.06, 2.0)) * exp(-t * 5.0) * 0.4;
float alpha = clamp(pool * 0.85 + edge, 0.0, 1.0) * (1.0 - smoothstep(0.8, 1.0, r)) * O27;
return vec4(vec3(1.0, 0.97, 0.9), alpha);
}
float Of1(ivec2 light) {
float stamp = float(((light.x >> 4) & 15) * 16 + ((light.y >> 4) & 15)) * O6b;
float now = mod(GameTime * 24000.0, O6c);
return mod(now - stamp + O6c, O6c) / 20.0;
}
struct GfxCell {
float reach;
int open;
vec3 offset;
};
GfxCell Oe4(vec3 tint) {
ivec3 bytes = ivec3(round(tint * 255.0));
int bits = (bytes.r << 16) | (bytes.g << 8) | bytes.b;
return GfxCell(
float(bits & 15) * 0.5,
(bits >> 4) & 63,
vec3(float(((bits >> 14) & 15) - 8), float(((bits >> 10) & 15) - 8), float(((bits >> 18) & 15) - 8))
);
}
float Oed(int open, vec3 f) {
float edge = 1.0;
if ((open & 1) != 0) edge = min(edge, f.x);
if ((open & 2) != 0) edge = min(edge, 1.0 - f.x);
if ((open & 4) != 0) edge = min(edge, f.y);
if ((open & 8) != 0) edge = min(edge, 1.0 - f.y);
if ((open & 16) != 0) edge = min(edge, f.z);
if ((open & 32) != 0) edge = min(edge, 1.0 - f.z);
return edge;
}
float Of0(vec3 lattice, vec3 f, GfxCell cell, float seconds) {
float distance = length((cell.offset + f - 0.5) * vec3(1.0, O7b, 1.0));
vec3 np = lattice * O76;
float lumps = Oec(np * 0.6 + vec3(0.0, 0.0, seconds * 0.05));
float detail = Oec(np + vec3(0.0, 0.0, seconds * 0.07)) * 0.6 + Oec(np * 2.3 + vec3(17.1, seconds * 0.11, 0.0)) * 0.4;
float radial = distance / (cell.reach + 0.7) + (lumps - 0.5) * 0.45;
float fill = smoothstep(0.0, O6f, seconds - distance * O79);
float body = (1.0 - smoothstep(0.45, 1.0, radial)) * fill;
float thin = 1.0 - smoothstep(0.0, 0.9, Oed(cell.open, clamp(f, 0.0, 1.0)));
float erosion = smoothstep(O6e - radial * 1.5, O6d, seconds);
return body + (detail - 0.5) * 0.7 - thin * 0.4 - erosion * 1.3;
}
vec4 Oef(int kind, vec3 view, vec3 tint, ivec2 light, out vec3 hit) {
hit = view;
float seconds = Of1(light);
if (seconds > O6d) {
return vec4(0.0);
}
vec3 dir = view / max(length(view), 1e-5);
bool inner = kind == O2c;
vec3 eye = -CameraOffset;
vec3 lo = floor(eye + view + dir * (inner ? -0.002 : 0.002));
bool eyeInside = all(greaterThanEqual(eye, lo)) && all(lessThan(eye, lo + 1.0));
if (inner != eyeInside) {
return vec4(0.0);
}
vec3 dirSign = vec3(dir.x < 0.0 ? -1.0 : 1.0, dir.y < 0.0 ? -1.0 : 1.0, dir.z < 0.0 ? -1.0 : 1.0);
vec3 inverse = dirSign / max(abs(dir), vec3(1e-6));
vec3 ta = (lo - eye) * inverse;
vec3 tb = (lo + 1.0 - eye) * inverse;
vec3 tMin = min(ta, tb);
float tExit = min(min(max(ta.x, tb.x), max(ta.y, tb.y)), max(ta.z, tb.z));
float t = inner ? O75 : max(max(tMin.x, tMin.y), tMin.z);
int axis = inner ? -1 : (tMin.x >= tMin.y && tMin.x >= tMin.z ? 0 : (tMin.y >= tMin.z ? 1 : 2));
GfxCell cell = Oe4(tint);
vec3 rise = vec3(0.0, seconds * O77, 0.0);
vec3 world = vec3(CameraBlockPos & 4095);
vec3 m = (eye + dir * (t + 1e-4) - rise) / O7c;
vec3 voxel = floor(m);
vec3 delta = O7c * abs(inverse);
vec3 next = t + (voxel + max(dirSign, 0.0) - m) * O7c * inverse;
vec3 colour = vec3(0.0);
float alpha = 0.0;
for (int i = 0; i < O74; i++) {
if (t >= tExit) break;
float leave = min(min(min(next.x, next.y), next.z), tExit);
vec3 centre = (voxel + 0.5) * O7c;
vec3 lattice = centre + world;
vec3 f = centre + rise - lo;
float density = Of0(lattice, f, cell, seconds);
if (density > O78) {
if (alpha == 0.0) hit = dir * t;
float face = axis == 1 ? (dir.y < 0.0 ? 1.0 : 0.8) : (axis == 0 ? 0.88 : (axis == 2 ? 0.93 : 0.9));
float tone = 0.94 + 0.08 * Oea(lattice * 7.31);
float y = cell.offset.y + f.y - 0.5;
vec3 shade = mix(O72, O70, clamp((y - O73) / (O71 - O73), 0.0, 1.0)) * face * tone;
float thickness = O7a * mix(0.35, 1.0, smoothstep(O78, O78 + 0.45, density));
float opacity = 1.0 - exp(-thickness * (leave - t));
colour += (1.0 - alpha) * opacity * shade;
alpha += (1.0 - alpha) * opacity;
}
if (next.x < next.y && next.x < next.z) {
t = next.x;
next.x += delta.x;
voxel.x += dirSign.x;
axis = 0;
} else if (next.y < next.z) {
t = next.y;
next.y += delta.y;
voxel.y += dirSign.y;
axis = 1;
} else {
t = next.z;
next.z += delta.z;
voxel.z += dirSign.z;
axis = 2;
}
}
return alpha > 0.0 ? vec4(colour / alpha, alpha) : vec4(0.0);
}
float Oe5(vec3 position, vec3 face, float faceDepth) {
vec4 faceClip = ProjMat * ModelViewMat * vec4(face, 1.0);
vec4 clip = ProjMat * ModelViewMat * vec4(position, 1.0);
float faceNdc = faceClip.z / faceClip.w;
float ndc = clip.z / clip.w;
bool halfRange = abs(faceDepth - (faceNdc * 0.5 + 0.5)) < abs(faceDepth - faceNdc);
return halfRange ? ndc * 0.5 + 0.5 : ndc;
}
vec4 Oe6(int kind, vec2 panel, vec3 tint) {
float t = Oe9(tint);
if (t > O29) return vec4(0.0);
return kind == O25 ? Oe7(panel, t) : Oe8(panel, t);
}
#endif
