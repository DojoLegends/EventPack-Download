#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
#define O7e 0.32
#define O7f 0.95
#define O80 0.006
#define O7d vec3(0.92, 0.97, 1.06)
uniform sampler2D InSampler;
uniform sampler2D BlurSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 BlurSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
float outOfFocus = 1.0 - Oe3(texCoord, OutSize, O7e, O7f);
vec2 fringe = (texCoord - 0.5) * O80 * outOfFocus;
vec3 sharp = Oe1(InSampler, texCoord, fringe);
vec3 soft = Oe1(BlurSampler, texCoord, fringe);
vec3 color = mix(sharp, soft, outOfFocus * 0.85);
color *= mix(vec3(1.0), O7d, outOfFocus);
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
