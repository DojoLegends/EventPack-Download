#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
#define O31 0.5
uniform sampler2D InSampler;
uniform sampler2D ClockSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 ClockSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
float t = clamp(Od8(texture(ClockSampler, vec2(0.5))) / O31, 0.0, 1.0);
float strength = (1.0 - t) * (1.0 - t);
vec3 color = Odf(texture(InSampler, texCoord).rgb, 1.0 + 0.2 * strength);
float rim = 1.0 - Oe3(texCoord, OutSize, 0.35, 1.0);
color = mix(color, vec3(1.0, 0.9, 0.7), rim * 0.22 * strength);
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
