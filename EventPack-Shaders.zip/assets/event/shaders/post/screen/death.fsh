#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
#define O1d 1.6
#define O1c vec3(0.42, 0.02, 0.03)
uniform sampler2D InSampler;
uniform sampler2D ClockSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 ClockSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
float seconds = Od8(texture(ClockSampler, vec2(0.5)));
float t = clamp(seconds / O1d, 0.0, 1.0);
float impact = smoothstep(0.0, 0.08, t);
float fadeOut = 1.0 - smoothstep(0.45, 1.0, t);
float breath = 1.0 + 0.12 * sin(clamp(t / 0.45, 0.0, 1.0) * O24);
float strength = impact * fadeOut;
float inner = mix(0.55, 0.22, strength) / breath;
float rim = 1.0 - Oe3(texCoord, OutSize, inner, inner + 0.55);
vec3 color = texture(InSampler, texCoord).rgb;
color = mix(color, O1c * (0.5 + 0.5 * Odd(color)), rim * 0.75 * strength);
color *= 1.0 - 0.1 * strength;
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
