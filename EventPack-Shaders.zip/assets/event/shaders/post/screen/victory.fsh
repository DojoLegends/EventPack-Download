#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
#define Ob6 6.0
#define Ob8 4
#define Ob7 0.7
#define Ob4 0.34
#define Ob5 vec3(1.0, 0.97, 0.9)
uniform sampler2D InSampler;
uniform sampler2D ClockSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 ClockSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
float O142(vec2 uv, float seconds) {
vec2 d = (uv - 0.5) * vec2(OutSize.x / OutSize.y, 1.0);
float radius = length(d);
float angle = atan(d.y, d.x);
float reach = smoothstep(0.0, 0.04, radius) * (1.0 - 0.55 * smoothstep(0.15, 1.0, radius));
float spacing = 2.0 * O24 / float(Ob8);
float off = abs(mod(angle - seconds * Ob7 + spacing * 0.5, spacing) - spacing * 0.5);
float beam = 1.0 - smoothstep(Ob4 * 0.6, Ob4, off);
float core = 1.0 - smoothstep(0.0, Ob4 * 0.55, off);
float source = exp(-pow(radius / 0.05, 2.0));
return (beam * 0.7 + core * 0.3) * reach + source * 0.8;
}
void main() {
float seconds = Od8(texture(ClockSampler, vec2(0.5)));
float t = clamp(seconds / Ob6, 0.0, 1.0);
float strength = smoothstep(0.0, 0.06, t) * (1.0 - smoothstep(0.75, 1.0, t));
vec3 color = texture(InSampler, texCoord).rgb;
color += Ob5 * O142(texCoord, seconds) * 0.3 * strength * (1.1 - Odd(color));
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
