#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
#define O66 4.0
#define O65 vec2(0.012, 0.016)
#define O67 0.02
#define O6a 0.045
#define O69 0.004
#define O68 4
uniform sampler2D InSampler;
uniform sampler2D ClockSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 ClockSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
vec2 O11e(float seconds) {
vec2 slow = vec2(Ode(seconds * 23.0), Ode(seconds * 23.0 + 71.3)) - 0.5;
vec2 fast = vec2(Ode(seconds * 57.0 + 13.1), Ode(seconds * 61.0 + 5.7)) - 0.5;
return slow * 2.0 + fast;
}
void main() {
float ramp = clamp(Od8(texture(ClockSampler, vec2(0.5))) / O66, 0.0, 1.0);
float strength = ramp * ramp * (0.25 + 0.75 * ramp);
float seconds = Oe0();
vec2 jitter = O11e(seconds);
float roll = (Ode(seconds * 17.0 + 31.0) - 0.5) * 2.0 * O67 * strength;
float aspect = OutSize.x / OutSize.y;
vec2 centred = (texCoord - 0.5) * vec2(aspect, 1.0);
centred = mat2(cos(roll), sin(roll), -sin(roll), cos(roll)) * centred;
vec2 uv = centred / vec2(aspect, 1.0) * (1.0 - O6a * strength) + 0.5 + jitter * O65 * strength;
vec2 smear = (O11e(seconds + 0.02) - jitter) * O65 * strength;
vec2 split = normalize(jitter + 1e-4) * O69 * strength;
vec3 color = vec3(0.0);
for (int i = 0; i < O68; i++) {
vec2 tap = clamp(uv + smear * (float(i) / float(O68 - 1) - 0.5), 0.0, 1.0);
color += Oe1(InSampler, tap, split);
}
color /= float(O68);
float glare = smoothstep(0.6, 1.0, ramp);
color = mix(color, color * vec3(1.25, 1.0, 0.75) + vec3(0.06, 0.02, 0.0), 0.6 * strength);
float rim = 1.0 - Oe3(texCoord, OutSize, 0.3, 0.95);
color = mix(color, vec3(1.0, 0.45, 0.12), rim * (0.25 + 0.15 * Ode(seconds * 9.0)) * strength);
color += vec3(1.0, 0.75, 0.45) * glare * glare * 0.35;
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
