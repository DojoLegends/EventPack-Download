#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
#define O30 vec3(0.85, 0.06, 0.08)
uniform sampler2D InSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
float seconds = Oe0();
float breath = 0.5 + 0.5 * sin(seconds * 1.6);
float rim = 1.0 - Oe3(texCoord, OutSize, 0.22 + 0.04 * breath, 0.95);
vec2 fromCentre = texCoord - 0.5;
float wobble = sin(texCoord.y * 48.0 + seconds * 5.0) * 0.0018 * rim;
vec2 uv = texCoord + vec2(wobble, 0.0);
vec3 color = Oe1(InSampler, uv, fromCentre * rim * 0.012);
color = Odf(color, 0.75);
color = mix(color, color * vec3(1.08, 0.86, 0.84), 0.6);
color = mix(color, O30, rim * (0.32 + 0.12 * breath));
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
