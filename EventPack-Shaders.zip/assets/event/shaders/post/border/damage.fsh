#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
#define O1b 0.45
#define O1a vec3(1.0, 0.12, 0.10)
uniform sampler2D InSampler;
uniform sampler2D ClockSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 ClockSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
float t = clamp(Od8(texture(ClockSampler, vec2(0.5))) / O1b, 0.0, 1.0);
float strength = (1.0 - t) * (1.0 - t);
vec2 fromCentre = texCoord - 0.5;
vec3 color = Oe1(InSampler, texCoord, fromCentre * 0.02 * strength);
float rim = 1.0 - Oe3(texCoord, OutSize, 0.15, 0.85);
color = mix(color, O1a, rim * 0.55 * strength);
color += O1a * 0.08 * strength;
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
