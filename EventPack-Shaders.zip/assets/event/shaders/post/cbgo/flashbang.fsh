#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:post_common.glsl>
uniform sampler2D InSampler;
uniform sampler2D AfterSampler;
uniform sampler2D ClockSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 AfterSize;
vec2 ClockSize;
};
layout(std140) uniform FlashConfig {
vec4 FlashTiming;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
#define O89 0.35
#define O87 0.32
#define O88 vec3(0.62, 0.63, 0.66)
#define O84 0.75
#define O8b 0.55
#define O83 0.012
#define O85 0.022
#define O86 0.4
#define O8a 8
vec3 O11f(sampler2D image, vec2 uv, float radius) {
vec3 sum = texture(image, uv).rgb;
for (int i = 0; i < O8a; i++) {
float a = float(i) / float(O8a) * 2.0 * O24;
sum += texture(image, uv + vec2(cos(a), sin(a)) * radius * vec2(OutSize.y / OutSize.x, 1.0)).rgb;
}
return sum / float(O8a + 1);
}
void main() {
float t = Od8(texture(ClockSampler, vec2(0.5)));
float hold = FlashTiming.x;
float end = max(FlashTiming.y, hold + 0.05);
float stun = FlashTiming.z * smoothstep(0.0, O89, t) * (1.0 - smoothstep(hold, end, t));
vec2 sway = vec2(cos(t * 1.1), sin(t * 0.8) * 0.6 + 0.4) * O85 * stun;
vec3 scene = O11f(InSampler, texCoord, O83 * stun);
vec3 echo = O11f(InSampler, texCoord + sway, O83 * stun * 1.5);
vec3 color = mix(scene, echo, 0.45 * stun);
color = Odf(color, 1.0 - O84 * stun);
color = mix(color, O88, O87 * stun);
float ghostLuma = Odd(O11f(AfterSampler, texCoord, 0.02));
float ghost = smoothstep(0.45, 0.95, ghostLuma) * FlashTiming.w * stun;
color *= 1.0 - O86 * ghost;
float tunnel = 1.0 - Oe3(texCoord, OutSize, 0.12, 0.75);
color *= 1.0 - O8b * stun * tunnel;
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
