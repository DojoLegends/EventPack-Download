#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
uniform sampler2D AfterSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
vec4 after = texture(AfterSampler, texCoord);
fragColor = after.a < 0.5 ? vec4(texture(InSampler, texCoord).rgb, 1.0) : after;
}
