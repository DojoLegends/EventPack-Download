#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:horror.glsl>
#define O1 6.0
#define O0 42.0
uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 DepthSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
float O110(vec2 uv) {
return log(Of2(texture(DepthSampler, uv).r));
}
void main() {
vec2 texel = 1.0 / OutSize;
vec3 scene = texture(InSampler, texCoord).rgb;
float dist = Of2(texture(DepthSampler, texCoord).r);
float gx = O110(texCoord + vec2(texel.x, 0.0)) - O110(texCoord - vec2(texel.x, 0.0));
float gy = O110(texCoord + vec2(0.0, texel.y)) - O110(texCoord - vec2(0.0, texel.y));
float edge = smoothstep(0.04, 0.25, length(vec2(gx, gy)));
float fog = smoothstep(O1, O0, dist);
float luma = Odd(scene);
vec3 color = vec3(0.42, 0.03, 0.05) * (0.25 + luma * 1.5);
color += vec3(1.0, 0.36, 0.16) * edge * 0.9;
color *= 1.0 - 0.9 * fog;
float saturation = max(scene.r, max(scene.g, scene.b)) - min(scene.r, min(scene.g, scene.b));
color = mix(color, scene, smoothstep(0.65, 0.85, saturation) * step(0.35, luma));
float scan = 0.94 + 0.06 * sin(texCoord.y * OutSize.y * 1.5 - Oe0() * 6.0);
color *= scan * mix(0.35, 1.0, Oe3(texCoord, OutSize, 0.3, 0.9));
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
