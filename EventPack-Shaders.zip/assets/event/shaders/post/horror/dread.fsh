#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:horror.glsl>
uniform sampler2D InSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
vec2 fromCentre = texCoord - 0.5;
float edge = dot(fromCentre, fromCentre);
vec3 color = Oe1(InSampler, texCoord, fromCentre * edge * 0.035);
float luma = Odd(color);
color = mix(color, vec3(luma), 0.65);
color *= mix(vec3(0.70, 0.86, 1.00), vec3(1.00, 0.97, 0.92), smoothstep(0.15, 0.75, luma));
color = pow(max(color, 0.0), vec3(1.3)) * 0.95;
float breath = 0.5 + 0.5 * sin(Oe0() * 0.8);
float vignette = Oe3(texCoord, OutSize, 0.18 + 0.05 * breath, 0.95);
color *= mix(0.12, 1.0, vignette);
color = Oda(color, floor(texCoord * OutSize), 0.07);
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
