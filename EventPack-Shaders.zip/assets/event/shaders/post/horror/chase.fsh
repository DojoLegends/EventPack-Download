#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:horror.glsl>
#define O19 8
uniform sampler2D InSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
float t = Oe0();
vec2 fromCentre = texCoord - 0.5;
vec2 jitter = vec2(Ode(t * 14.0), Ode(t * 14.0 + 31.0)) - 0.5;
vec2 split = fromCentre * 0.010 + jitter * 0.006;
vec3 color = vec3(0.0);
for (int i = 0; i < O19; i++) {
float k = float(i) / float(O19);
color += Oe1(InSampler, texCoord - fromCentre * k * 0.045, split);
}
color /= float(O19);
float pulse = 0.5 + 0.5 * sin(t * 9.0);
float rim = 1.0 - Oe3(texCoord, OutSize, 0.2, 0.8);
color = mix(color, vec3(0.55, 0.02, 0.02), clamp(rim * (0.45 + 0.35 * pulse), 0.0, 1.0));
float catchLight = Ode(t * 6.0) > 0.78 ? 0.65 : 1.0;
color = mix(vec3(Odd(color)), color, 0.6) * catchLight;
color = Oda(color, floor(texCoord * OutSize), 0.09);
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
