#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:horror.glsl>
uniform sampler2D InSampler;
uniform sampler2D BlurSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
vec2 BlurSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
float t = Oe0();
vec2 drift = vec2(sin(t * 0.7), cos(t * 0.45)) * vec2(0.014, 0.006);
vec3 sharp = texture(InSampler, texCoord).rgb;
vec3 blur = texture(BlurSampler, texCoord).rgb;
vec3 ghost = texture(BlurSampler, texCoord + drift).rgb;
vec3 color = mix(sharp, blur, 0.7);
color = mix(color, ghost, 0.35);
float luma = Odd(color);
color = mix(vec3(luma), color, 0.15) * vec3(1.0, 0.82, 0.80);
float breath = 0.5 + 0.5 * sin(t * 1.3);
float tunnel = Oe3(texCoord, OutSize, 0.05 + 0.10 * breath, 0.62 + 0.08 * breath);
color *= tunnel;
color = mix(color, vec3(0.18, 0.0, 0.0), (1.0 - tunnel) * 0.35);
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
