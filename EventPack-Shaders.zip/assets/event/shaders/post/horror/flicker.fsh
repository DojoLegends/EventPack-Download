#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
#include <event:horror.glsl>
uniform sampler2D InSampler;
layout(std140) uniform SamplerInfo {
vec2 OutSize;
vec2 InSize;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
float O11d() {
float tick = floor(Oe2());
float stutter = Odc(tick) > 0.86 ? mix(0.2, 0.65, Odc(tick + 0.5)) : 1.0;
float window = floor(tick / 140.0);
float cutStart = window * 140.0 + floor(Odc(window) * 120.0);
float cut = tick >= cutStart && tick < cutStart + 10.0 ? 0.06 : 1.0;
float sag = 0.85 + 0.15 * Ode(Oe0() * 0.7);
return stutter * cut * sag;
}
void main() {
vec3 color = texture(InSampler, texCoord).rgb;
float light = O11d();
color = mix(vec3(Odd(color)), color, 0.4 + 0.6 * light) * light;
fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
