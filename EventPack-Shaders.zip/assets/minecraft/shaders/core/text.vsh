#version 330
#extension GL_ARB_separate_shader_objects : require
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:plate_effects.glsl>
#include <minecraft:text_effects.glsl>
#define O46 250
#define O47 251
#define O48 252
#define O36 vec2(2.0, 240.0)
#define O37 vec2(53.0, 8.0)
#define O32 8.0
#define O34 4.0
#define O35 40.0
#define O4a 7
#define O4f 6
#define O33 252.0
layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif
uniform sampler2D Sampler0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) flat out int lbStyle;
layout(location = 5) flat out float lbProgress;
layout(location = 6) flat out float lbHue;
layout(location = 7) flat out float lbAlpha;
layout(location = 8) flat out vec2 lbGuiSize;
layout(location = 9) out vec2 lbUvOrigin;
layout(location = 10) out vec2 lbUvSize;
layout(location = 11) out vec2 lbScreenUv;
layout(location = 12) flat out vec3 peColor;
layout(location = 13) flat out vec4 peShape;
layout(location = 14) out vec3 peTopLeft;
layout(location = 15) out vec3 peBottomRight;
const vec2[4] LB_CORNERS = vec2[4](
vec2(0.0, 0.0), vec2(0.0, 1.0), vec2(1.0, 1.0), vec2(1.0, 0.0)
);
int O104(vec2 uv) {
return int(round(textureLod(Sampler0, uv, 0.0).a * 255.0));
}
vec2 Of9(vec2 corner) {
return Position.xy + (0.5 - corner) * O32;
}
bool Ofb(vec2 corner, vec2 guiSize) {
float below = Of9(corner).y - guiSize.y * 0.5;
return GameTime <= 0.0 && below > -O34 && below < O35;
}
void Of7(vec2 corner, vec2 uvOrigin, vec2 uvSize) {
vec2 position = Of9(corner) + (corner - 0.5) * O37;
gl_Position = ProjMat * ModelViewMat * vec4(position, Position.z, 1.0);
texCoord0 = uvOrigin + (O36 + corner * O37) / O33 * uvSize;
}
int Of8(vec2 uv, vec2 uvSize, vec2 texel, out vec2 corner) {
for (int i = 0; i < 4; i++) {
vec2 origin = uv - LB_CORNERS[i] * uvSize;
if (any(lessThan(origin, -texel)) || any(greaterThan(origin + uvSize, vec2(1.0) + texel))) {
continue;
}
int marker = O104(origin + texel * 0.5);
if (marker >= O46 && marker <= O48 && O104(origin + texel * 1.5) == marker) {
corner = LB_CORNERS[i];
return marker;
}
}
corner = vec2(0.0);
return 0;
}
bool O116(vec2 uv, vec2 texel, out vec2 corner, out int effect, out float height, out float topOffset) {
vec2 uvSize = O5a * texel;
for (int i = 0; i < 4; i++) {
vec2 origin = uv - LB_CORNERS[i] * uvSize;
if (any(lessThan(origin, -texel)) || any(greaterThan(origin + uvSize, vec2(1.0) + texel))) {
continue;
}
if (O104(origin + texel * vec2(0.5, 0.5)) == O60
&& O104(origin + texel * vec2(1.5, 0.5)) == O60
&& O104(origin + texel * vec2(0.5, 1.5)) == O60
&& O104(origin + texel * vec2(1.5, 1.5)) == O60) {
corner = LB_CORNERS[i];
effect = O104(origin + texel * vec2(0.5, 2.5));
height = float(O104(origin + texel * vec2(1.5, 2.5)));
topOffset = float(O104(origin + texel * vec2(0.5, 3.5)));
return true;
}
}
corner = vec2(0.0);
effect = 0;
height = 0.0;
topOffset = 0.0;
return false;
}
bool O113(vec2 texel) {
vec2 corner;
int effect;
float height;
float topOffset;
if (!O116(UV0, texel, corner, effect, height, topOffset)) {
return false;
}
ivec3 rgb = ivec3(round(Color.rgb * 255.0));
float width = float(((rgb.g & 1) << 8) | rgb.b);
bool valid = effect >= O5c && effect <= O5b && width >= 3.0 && height >= 3.0;
if (!valid || ProjMat[3][3] != 1.0 || Color.a <= 0.0) {
gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
return true;
}
lbStyle = O62 + effect;
lbAlpha = Color.a;
peColor = vec3(float(rgb.r >> 4), float(rgb.r & 15), float(rgb.g >> 4)) / 15.0;
peShape = vec4(width, height, PE_PERIODS[(rgb.g >> 1) & 7], topOffset);
peTopLeft = corner == vec2(0.0) ? vec3(Position.xy, 1.0) : vec3(0.0);
peBottomRight = corner == vec2(1.0) ? vec3(Position.xy, 1.0) : vec3(0.0);
vec2 plate = vec2(width, height + topOffset);
vec2 position = Position.xy + mix(-plate, plate * O61, corner);
lbScreenUv = position;
gl_Position = ProjMat * ModelViewMat * vec4(position, Position.z, 1.0);
return true;
}
float O120(ivec2 texel, ivec2 atlas) {
if (any(lessThan(texel, ivec2(0))) || any(greaterThanEqual(texel, atlas))) {
return 0.0;
}
return texelFetch(Sampler0, texel, 0).a;
}
bool O132(ivec2 atlas, ivec2 corner, out ivec2 origin, out vec2 size, out int rows) {
size = vec2(0.0);
rows = 0;
origin = corner;
while (rows < 64 && O120(origin, atlas) <= 0.0) {
rows++;
origin.y++;
}
if (rows >= 64) {
return false;
}
int width = 1;
while (width < 64 && O120(origin + ivec2(width, 0), atlas) > 0.0) {
width++;
}
int height = 1;
while (height < int(O9c) - 1 && O120(origin + ivec2(0, height), atlas) > 0.0) {
height++;
}
size = vec2(float(width), float(height));
return true;
}
bool O121(vec4 light) {
ivec3 rgb = ivec3(round(Color.rgb * 255.0));
if ((rgb.r & O9a) != O99) {
return false;
}
int effect = rgb.g >> 4;
vec3 colour = vec3(float(rgb.g & 15), float(rgb.b >> 4), float(rgb.b & 15)) / 15.0;
float extra = float(rgb.r & 3);
if (effect == Oa8 || (effect >= O9e && effect <= O9f)) {
int slot = effect == Oa8 ? 0 : effect - O9e + 1;
extra = float(slot * 4 + (rgb.r & 3)) * Oa5;
effect = Oa8;
} else if (effect == Oa9) {
extra = float(rgb.b) * Oa5;
colour = vec3(1.0);
} else if (effect == 0 && (rgb.r & 3) != 0) {
effect = O92;
extra = float(rgb.b);
colour = vec3(1.0);
}
vertexColor = vec4(colour, Color.a) * light;
if (effect < 1 || effect > O9b || ProjMat[3][3] != 1.0) {
return true;
}
ivec2 atlas = textureSize(Sampler0, 0);
vec2 uv = UV0 * vec2(atlas);
vec2 corner = step(0.5, fract(uv));
bool topLeft = corner == vec2(0.0);
ivec2 origin = ivec2(0);
vec2 size = vec2(0.0);
int rows = 0;
if (topLeft && !O132(atlas, ivec2(floor(uv)), origin, size, rows)) {
return true;
}
lbStyle = Oac + effect;
lbProgress = extra;
lbAlpha = Color.a;
lbGuiSize = abs(vec2(2.0 / ProjMat[0][0], 2.0 / ProjMat[1][1]));
peColor = colour;
lbUvOrigin = topLeft ? vec2(origin) : vec2(0.0);
lbUvSize = topLeft ? vec2(size.x, size.y + float(rows) * O9c) : vec2(0.0);
texCoord0 = corner == vec2(1.0) ? uv : vec2(0.0);
peTopLeft = topLeft ? vec3(Position.xy, 1.0) : vec3(0.0);
peBottomRight = corner == vec2(1.0) ? vec3(Position.xy, 1.0) : vec3(0.0);
vec2 position = Position.xy + (corner * 2.0 - 1.0) * O98;
lbScreenUv = position;
gl_Position = ProjMat * ModelViewMat * vec4(position, Position.z, 1.0);
return true;
}
void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
sphericalVertexDistance = fog_spherical_distance(Position);
cylindricalVertexDistance = fog_cylindrical_distance(Position);
vec4 light = sample_lightmap(Sampler2, UV2);
#else
vec4 light = vec4(1.0);
#endif
vertexColor = Color * light;
texCoord0 = UV0;
lbStyle = 0;
lbProgress = 0.0;
lbHue = 0.0;
lbAlpha = 1.0;
lbGuiSize = vec2(1.0);
lbUvOrigin = vec2(0.0);
lbUvSize = vec2(1.0);
lbScreenUv = vec2(0.0);
peColor = vec3(0.0);
peShape = vec4(1.0);
peTopLeft = vec3(0.0);
peBottomRight = vec3(0.0);
gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
vec2 uvSize = O33 * texel;
vec2 corner;
int marker = Of8(UV0, uvSize, texel, corner);
if (marker == 0) {
if (!O113(texel)) {
O121(light);
}
return;
}
vec2 uvOrigin = UV0 - corner * uvSize;
if (ProjMat[3][3] != 1.0) {
gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
return;
}
vec2 guiSize = abs(vec2(2.0 / ProjMat[0][0], 2.0 / ProjMat[1][1]));
if (marker == O48 && !Ofb(corner, guiSize)) {
Of7(corner, uvOrigin, uvSize);
return;
}
int red = int(round(Color.r * 255.0));
bool alwaysLoading = marker != O46;
int style = alwaysLoading ? O4f : red - 128;
if ((!alwaysLoading && red < 128) || style < 1 || style > O4a || Color.a <= 0.0) {
gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
return;
}
lbStyle = style;
lbProgress = round(Color.g * 255.0) / 255.0;
lbHue = round(Color.b * 255.0);
lbAlpha = Color.a;
lbUvOrigin = uvOrigin;
lbUvSize = uvSize;
lbGuiSize = guiSize;
lbScreenUv = corner;
float depth = gl_Position.z;
gl_Position = ProjMat * vec4(corner * lbGuiSize, 0.0, 1.0);
gl_Position.z = depth;
}
