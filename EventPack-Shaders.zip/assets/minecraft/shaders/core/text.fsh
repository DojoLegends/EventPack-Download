#version 330
#extension GL_ARB_separate_shader_objects : require
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:loading_bars.glsl>
#include <minecraft:plate_effects.glsl>
uniform sampler2D Sampler0;
#define O8f
#include <minecraft:text_effects.glsl>
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) flat in int lbStyle;
layout(location = 5) flat in float lbProgress;
layout(location = 6) flat in float lbHue;
layout(location = 7) flat in float lbAlpha;
layout(location = 8) flat in vec2 lbGuiSize;
layout(location = 9) in vec2 lbUvOrigin;
layout(location = 10) in vec2 lbUvSize;
layout(location = 11) in vec2 lbScreenUv;
layout(location = 12) flat in vec3 peColor;
layout(location = 13) flat in vec4 peShape;
layout(location = 14) in vec3 peTopLeft;
layout(location = 15) in vec3 peBottomRight;
#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif
vec4 Oc5(vec4 color) {
#ifdef OIT_ACCUMULATE
color = sampleColorForAccumulation(color);
#endif
#if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)
#ifdef OIT_ACCUMULATE
vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
#else
vec4 fogColor = FogColor;
#endif
color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
#endif
return color;
}
void main() {
if (lbStyle > 0) {
vec2 guiCoord = lbScreenUv * lbGuiSize;
float time = GameTime * 1200.0;
float fade = lbAlpha * ColorModulator.a;
vec4 bar;
if (lbStyle > Oac) {
TfxGlyph glyph;
bool isGlyph = O12d(lbScreenUv, peTopLeft, peBottomRight, lbUvOrigin / max(peTopLeft.z, 1e-5), lbUvSize / max(peTopLeft.z, 1e-5), texCoord0 / max(peBottomRight.z, 1e-5), glyph);
bar = isGlyph ? O136(lbStyle, glyph, peColor, fade, lbGuiSize, time, lbProgress) : vec4(0.0);
} else if (lbStyle == O4f) {
vec2 screen = lbScreenUv * ScreenSize;
bar = Ofc(screen, ScreenSize, fade, time, GameTime > 0.0, Sampler0, lbUvOrigin, lbUvSize);
} else if (lbStyle > O62) {
bar = O11a(lbStyle, lbScreenUv, peTopLeft, peBottomRight, peShape, peColor, time);
bar.a *= fade;
} else {
bar = O107(lbStyle, guiCoord, lbGuiSize, lbProgress, lbHue, time);
bar.a *= fade;
}
if (bar.a <= 0.0) {
discard;
}
#ifdef OIT_ALPHA_ONLY
executeAlphaOnlyPhase(gl_FragCoord.z, bar.a);
#else
fragColor = bar;
#endif
return;
}
#ifdef IS_GRAYSCALE
vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
vec4 texColor = texture(Sampler0, texCoord0);
#endif
vec4 color = texColor * vertexColor * ColorModulator;
if (color.a < 0.1) {
discard;
}
#ifdef OIT_ALPHA_ONLY
executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
fragColor = Oc5(color);
#endif
}
