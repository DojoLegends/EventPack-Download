#define O4d  3.14159265359
#define O50 6.28318530718
#define O4a 7
#define O4f 6
#define O33 252.0
#define O49 2.0
#define O51      vec4(0.04, 0.04, 0.06, 0.85)
#define O4e vec4(0.34, 0.34, 0.42, 0.60)
#define O4b      vec4(0.05, 0.05, 0.07, 0.80)
#define O4c vec4(0.19, 0.19, 0.24, 0.90)
bool Of6(vec2 p, float x, float y, float w, float h) {
return p.x >= x && p.x < x + w && p.y >= y && p.y < y + h;
}
vec3 Ofa(float t) {
t = fract(t);
float r = abs(t * 6.0 - 3.0) - 1.0;
float g = 2.0 - abs(t * 6.0 - 2.0);
float b = 2.0 - abs(t * 6.0 - 4.0);
return clamp(vec3(r, g, b), 0.0, 1.0);
}
vec3 Of4(float b, float time) {
if (b < 0.5)   return vec3(1.0);
if (b > 254.5) return Ofa(time * 0.25);
return Ofa(b / 255.0);
}
vec4 O105(vec4 src, vec4 dst) {
float a = src.a + dst.a * (1.0 - src.a);
if (a <= 0.0) return vec4(0.0);
return vec4((src.rgb * src.a + dst.rgb * dst.a * (1.0 - src.a)) / a, a);
}
vec4 O106(vec2 p, float x, float y, float w, float h) {
if (!Of6(p, x, y, w, h)) return vec4(0.0);
vec2 d = min(p - vec2(x, y), vec2(x + w, y + h) - p);
if (d.x < 1.0 && d.y < 1.0) return vec4(0.0);
if (d.x < 1.0 || d.y < 1.0) return O4c;
return O4b;
}
bool O108(vec2 p, vec2 c, float radius, float thick, out float angle) {
vec2 d = p - c;
float r = length(d);
angle = fract(atan(d.x, -d.y) / O50);
return r >= radius - thick && r <= radius;
}
vec4 O109(vec2 p, vec2 c, float radius, float thick, vec3 col, float time) {
float a;
if (!O108(p, c, radius, thick, a)) return vec4(0.0);
float head = fract(time * 0.85);
float tail = fract(head - a);
float k = 1.0 - smoothstep(0.0, 0.6, tail);
return O105(vec4(col, k), O4e);
}
vec4 Of5(vec2 p, vec2 c, float radius, float thick, float progress, vec3 col) {
float a;
if (!O108(p, c, radius, thick, a)) return vec4(0.0);
if (a <= progress) {
float lead = smoothstep(progress - 0.3, progress, a);
return vec4(clamp(col * (0.7 + 0.5 * lead), 0.0, 1.0), 1.0);
}
return O4e;
}
vec4 O10a(vec2 p, vec2 gui, float progress, vec3 col, float time) {
const float W = 182.0;
const float H = 9.0;
float x = floor(gui.x * 0.5 - W * 0.5);
float y = floor(gui.y * 0.72);
vec4 result = O106(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
if (!Of6(p, x, y, W, H)) return result;
if (!Of6(p, x + 1.0, y + 1.0, W - 2.0, H - 2.0)) {
return O105(vec4(col * 0.55, 1.0), result);
}
float innerX = x + 2.0;
float innerW = W - 4.0;
float fill = floor(innerW * progress);
if (p.x < innerX + fill) {
float band = fract((p.x - p.y) * 0.05 - time * 0.6);
float sheen = 0.85 + 0.15 * smoothstep(0.75, 1.0, band);
float shade = p.y < y + 3.0 ? 1.15 : (p.y > y + H - 4.0 ? 0.75 : 1.0);
return O105(vec4(clamp(col * sheen * shade, 0.0, 1.0), 1.0), result);
}
return O105(O51, result);
}
vec4 O10d(vec2 p, vec2 gui, float progress, vec3 col, float time) {
const float CELLS = 20.0;
const float CELL = 8.0;
const float GAP = 1.0;
const float H = 8.0;
float W = CELLS * CELL + (CELLS - 1.0) * GAP;
float x = floor(gui.x * 0.5 - W * 0.5);
float y = floor(gui.y * 0.72);
vec4 result = O106(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
if (!Of6(p, x, y, W, H)) return result;
float local = p.x - x;
float index = floor(local / (CELL + GAP));
if (local - index * (CELL + GAP) >= CELL) return result;
float filled = progress * CELLS;
if (index < floor(filled)) {
return O105(vec4(col, 1.0), result);
}
if (index < filled) {
float pulse = 0.45 + 0.35 * sin(time * 6.0);
return O105(vec4(col * pulse, 1.0), result);
}
return O105(O51, result);
}
vec4 O10f(vec2 p, vec2 gui, float progress, vec3 col, float time) {
const float H = 3.0;
if (p.y >= H + 1.0) return vec4(0.0);
if (p.y >= H) return vec4(0.0, 0.0, 0.0, 0.45);
float head = floor(gui.x * progress);
if (p.x < head) {
float edge = smoothstep(head - 24.0, head, p.x);
return vec4(clamp(col * (0.8 + 0.6 * edge), 0.0, 1.0), 1.0);
}
float glow = clamp(1.0 - (p.x - head) / 10.0, 0.0, 1.0);
return O105(vec4(col, glow * 0.45), O51);
}
vec4 O10c(vec2 p, vec2 gui, float progress, vec3 col, float time) {
const float RADIUS = 26.0;
const float THICK = 5.0;
vec2 c = vec2(floor(gui.x * 0.5), floor(gui.y * 0.5));
float r = length(p - c);
vec4 result = vec4(0.0);
if (r <= RADIUS + 4.0) result = O4b;
if (r > RADIUS + 3.0 && r <= RADIUS + 4.0) result = O4c;
return O105(Of5(p, c, RADIUS, THICK, progress, col), result);
}
vec4 O10b(vec2 p, vec2 gui, float progress, vec3 col, float time) {
const float W = 182.0;
const float H = 9.0;
const float BLOCK = 46.0;
float x = floor(gui.x * 0.5 - W * 0.5);
float y = floor(gui.y * 0.72);
vec4 result = O106(p, x - 5.0, y - 5.0, W + 10.0, H + 10.0);
if (!Of6(p, x, y, W, H)) return result;
if (!Of6(p, x + 1.0, y + 1.0, W - 2.0, H - 2.0)) {
return O105(vec4(col * 0.55, 1.0), result);
}
float innerX = x + 2.0;
float travel = (W - 4.0) - BLOCK;
float eased = 0.5 - 0.5 * cos(fract(time * 0.4) * O50);
float local = p.x - (innerX + floor(travel * eased));
if (local >= 0.0 && local < BLOCK) {
float taper = clamp(min(local, BLOCK - 1.0 - local) / 8.0, 0.0, 1.0);
return O105(vec4(clamp(col * (0.5 + 0.6 * taper), 0.0, 1.0), 1.0), result);
}
return O105(O51, result);
}
#define O38       vec3(0.064, 0.053, 0.053)
#define O39     vec3(0.140, 0.122, 0.122)
#define O45   vec3(1.000, 0.246, 0.223)
#define O44       vec3(0.187, 0.163, 0.162)
#define O40 vec2(239.0, 234.0)
#define O3d vec2(125.5, 121.0)
#define O3f  0.11
#define O3e     0.03
#define O43    0.06
#define O41    0.022
#define O42    0.0055
#define O3c 0.11
#define O3a vec2(0.14, 0.07)
#define O3b 0.6
float Off(float x) {
x = clamp(x, 0.0, 1.0);
return x * x * (3.0 - 2.0 * x);
}
float O102(vec2 p, vec2 a, vec2 b) {
vec2 pa = p - a;
vec2 ba = b - a;
return length(pa - ba * clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0));
}
float Ofd(vec2 p) {
const float H = 0.86602540378;
float v = p.y / H;
float u = p.x - 0.5 * v;
float d = min(abs(fract(u + 0.5) - 0.5), abs(fract(v + 0.5) - 0.5));
d = min(d, abs(fract(u + v + 0.5) - 0.5)) * H;
vec2 cell = floor(vec2(u, v));
vec2 f = vec2(u, v) - cell;
vec2 c0, c1, c2;
if (f.x + f.y < 1.0) {
c0 = cell; c1 = cell + vec2(1.0, 0.0); c2 = cell + vec2(0.0, 1.0);
} else {
c0 = cell + vec2(1.0, 1.0); c1 = cell + vec2(1.0, 0.0); c2 = cell + vec2(0.0, 1.0);
}
vec2 v0 = vec2(c0.x + 0.5 * c0.y, c0.y * H);
vec2 v1 = vec2(c1.x + 0.5 * c1.y, c1.y * H);
vec2 v2 = vec2(c2.x + 0.5 * c2.y, c2.y * H);
vec2 centre = (v0 + v1 + v2) / 3.0;
d = min(d, O102(p, centre, v0));
d = min(d, O102(p, centre, v1));
d = min(d, O102(p, centre, v2));
return d;
}
vec3 Ofe(vec2 screen, vec2 size, float time) {
vec3 color = O38;
float side = size.y * O3c;
vec2 p = screen / side + time * O3a;
float line = Ofd(p) * side;
return mix(color, O39, clamp(O3b + 0.5 - line, 0.0, 1.0));
}
vec4 O101(sampler2D atlas, vec2 uvOrigin, vec2 uvSize, vec2 t) {
t = clamp(t, vec2(0.0), vec2(O33 - 1.0));
if (t.x < O49 && t.y < O49) return vec4(0.0);
vec4 c = texture(atlas, uvOrigin + (t + 0.5) / O33 * uvSize);
return vec4(c.rgb * c.a, c.a);
}
vec4 O100(vec2 screen, vec2 centre, float height, sampler2D atlas, vec2 uvOrigin, vec2 uvSize) {
float texelsPerPixel = O40.y / height;
vec2 t = (screen - centre) * texelsPerPixel + O3d - 0.5;
vec2 extent = O40 * 0.5 + 1.0;
if (any(greaterThan(abs(t + 0.5 - O3d), extent))) return vec4(0.0);
vec2 spread = vec2(texelsPerPixel * 0.25);
vec4 sum = vec4(0.0);
for (int i = 0; i < 4; i++) {
vec2 offset = vec2(i == 1 || i == 3 ? 1.0 : -1.0, i >= 2 ? 1.0 : -1.0) * spread;
vec2 q = t + offset;
vec2 base = floor(q);
vec2 f = q - base;
vec4 a = O101(atlas, uvOrigin, uvSize, base);
vec4 b = O101(atlas, uvOrigin, uvSize, base + vec2(1.0, 0.0));
vec4 c = O101(atlas, uvOrigin, uvSize, base + vec2(0.0, 1.0));
vec4 d = O101(atlas, uvOrigin, uvSize, base + vec2(1.0, 1.0));
sum += mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
return sum * 0.25;
}
vec4 O103(vec2 screen, vec2 centre, float radius, float width, float time, bool live) {
vec2 d = screen - centre;
float dist = length(d);
float edge = width * 0.5;
float band = 1.0 - smoothstep(edge - 0.75, edge + 0.75, abs(dist - radius));
if (band <= 0.0) return vec4(0.0);
const float SWEEP = 0.72;
const float MIN_ARC = 0.05;
float start = 0.08;
float arcLength = 0.3;
if (live) {
float cycle = time * 0.65;
float phase = fract(cycle);
float head = Off(phase * 2.0) * SWEEP;
float tail = Off(phase * 2.0 - 1.0) * SWEEP;
start = fract(time * 0.3 + floor(cycle) * SWEEP + tail);
arcLength = head - tail + MIN_ARC;
}
float angle = fract(atan(d.x, -d.y) / O50);
float into = fract(angle - start);
float pixels = dist * O50;
float inArc = clamp(min(into, arcLength - into) * pixels + 0.5, 0.0, 1.0);
vec3 color = mix(O44, O45, inArc);
return vec4(color * band, band);
}
vec4 Ofc(vec2 screen, vec2 size, float coverage, float time, bool live,
sampler2D atlas, vec2 uvOrigin, vec2 uvSize) {
float fade = Off(coverage);
if (fade <= 0.0) return vec4(0.0);
vec3 color = Ofe(screen, size, time);
vec2 centre = size * 0.5;
float logoHeight = size.y * O3f;
vec2 logoCentre = vec2(centre.x, centre.y - size.y * O3e - logoHeight * 0.5);
vec4 logo = O100(screen, logoCentre, logoHeight, atlas, uvOrigin, uvSize);
color = color * (1.0 - logo.a) + logo.rgb;
vec2 spinnerCentre = vec2(centre.x, centre.y + size.y * O43);
vec4 spinner = O103(screen, spinnerCentre, size.y * O41,
max(size.y * O42, 2.0), time, live);
color = color * (1.0 - spinner.a) + spinner.rgb;
return vec4(color, fade);
}
vec4 O10e(vec2 p, vec2 gui, float progress, vec3 col, float time) {
vec2 c = vec2(floor(gui.x * 0.5), floor(gui.y * 0.5));
return O109(p, c, 13.0, 3.0, col, time);
}
vec4 O107(int style, vec2 guiCoord, vec2 gui, float progress, float hueByte, float time) {
vec2 p = floor(guiCoord) + 0.5;
vec3 col = Of4(hueByte, time);
progress = clamp(progress, 0.0, 1.0);
if (style == 1) return O10a(p, gui, progress, col, time);
if (style == 2) return O10d(p, gui, progress, col, time);
if (style == 3) return O10f(p, gui, progress, col, time);
if (style == 4) return O10c(p, gui, progress, col, time);
if (style == 5) return O10b(p, gui, progress, col, time);
if (style == 7) return O10e(p, gui, progress, col, time);
return vec4(0.0);
}
