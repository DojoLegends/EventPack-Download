#ifndef O52
#define O52
#define O56 208
#define O55 90
#define O54 215
#define O53 0.8
#define O57 0.45
#define O59 0.012
#define O58 2
const vec3 PD_PALETTE[O58] = vec3[O58](
vec3(1.0, 1.0, 1.0),
vec3(159.0, 227.0, 255.0) / 255.0
);
const vec2 PD_INWARD[4] = vec2[4](vec2(-0.5, -0.5), vec2(-0.5, 0.5), vec2(0.5, 0.5), vec2(0.5, -0.5));
bool O112(sampler2D atlas, vec2 uv, int vertex) {
int corner = vertex % 4;
ivec2 size = textureSize(atlas, 0);
ivec2 texel = clamp(ivec2(floor(uv * vec2(size) + PD_INWARD[corner])), ivec2(0), size - 1);
ivec4 marker = ivec4(round(texelFetch(atlas, texel, 0) * 255.0));
return marker == ivec4(O56 + corner, O55, O54, 1);
}
vec3 O111(vec3 colour) {
float peak = max(colour.r, max(colour.g, colour.b));
if (peak < O57) {
return colour;
}
vec3 lifted = colour / peak;
for (int i = 0; i < O58; i++) {
vec3 target = PD_PALETTE[i];
vec3 shape = target / max(target.r, max(target.g, target.b));
vec3 low = shape * O53 - O59;
vec3 high = min(vec3(1.0), shape / O53) + O59;
if (all(greaterThanEqual(lifted, low)) && all(lessThanEqual(lifted, high))) {
return target;
}
}
return colour;
}
#endif
