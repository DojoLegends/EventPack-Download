#define O60 23
#define O5a vec2(2.0, 64.0)
#define O61 4.0
#define O5c 1
#define O5b 2
#define O62 15
#define O64 (O62 + O5c)
#define O63 (O62 + O5b)
const float PE_PERIODS[8] = float[8](4.0, 3.0, 2.0, 1.5, 1.0, 0.75, 0.5, 0.25);
#define O5d 0.25
#define O5f 4.0
#define O5e 32.0
float O11c(vec2 p, vec2 size) {
float right = size.x - 1.0;
float bottom = size.y - 1.0;
float across = size.x - 2.0;
float down = size.y - 2.0;
bool onTop = p.y == 0.0;
bool onBottom = p.y == bottom;
bool onLeft = p.x == 0.0;
bool onRight = p.x == right;
if ((onTop || onBottom) && (onLeft || onRight)) return -1.0;
if (onTop) return p.x - 1.0;
if (onRight) return across + p.y - 1.0;
if (onBottom) return across + down + (right - 1.0 - p.x);
if (onLeft) return 2.0 * across + down + (bottom - 1.0 - p.y);
return -1.0;
}
float O11b(vec2 size) {
return 2.0 * (size.x - 2.0) + 2.0 * (size.y - 2.0);
}
vec4 O117(float period, vec3 colour, float time) {
return fract(time / period) < 0.5 ? vec4(colour, 1.0) : vec4(0.0);
}
vec4 O115(float s, vec2 size, float period, vec3 colour, float time) {
float lap = O11b(size);
float head = floor(fract(time / period) * lap);
float behind = mod(head - s + lap, lap);
float segment = clamp(floor(lap * O5d), O5f, O5e);
return behind < segment ? vec4(colour, 1.0) : vec4(0.0);
}
vec4 O114(int style, float s, vec2 size, float period, vec3 colour, float time) {
if (style == O64) return O117(period, colour, time);
if (style == O63) return O115(s, size, period, colour, time);
return vec4(0.0);
}
bool O118(vec2 p, vec2 size) {
return (p.x == 1.0 || p.x == size.x - 2.0) && (p.y == 1.0 || p.y == size.y - 2.0);
}
vec4 O119(int style, vec2 local, vec2 size, float period, vec3 colour, float time) {
vec2 p = floor(local);
if (any(lessThan(p, vec2(0.0))) || any(greaterThanEqual(p, size))) return vec4(0.0);
float s = O11c(p, size);
if (s >= 0.0) return O114(style, s, size, period, colour, time);
if (!O118(p, size)) return vec4(0.0);
vec2 edge = vec2(p.x == 1.0 ? 0.0 : size.x - 1.0, p.y == 1.0 ? 0.0 : size.y - 1.0);
vec4 alongEdge = O114(style, O11c(vec2(p.x, edge.y), size), size, period, colour, time);
if (alongEdge.a > 0.0) return alongEdge;
return O114(style, O11c(vec2(edge.x, p.y), size), size, period, colour, time);
}
vec4 O11a(int style, vec2 position, vec3 topLeft, vec3 bottomRight, vec4 shape, vec3 colour, float time) {
if (topLeft.z <= 0.0 || bottomRight.z <= 0.0) return vec4(0.0);
vec2 origin = topLeft.xy / topLeft.z;
vec2 scale = (bottomRight.xy / bottomRight.z - origin) / O5a;
vec2 local = (position - origin) / scale - vec2(0.0, shape.w);
return O119(style, local, shape.xy, shape.z, colour, time);
}
